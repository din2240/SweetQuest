// Core 2D Platformer Engine for GULIGO! FOOD ADVENTURE
// Physics, collisions, triggers, checkpoints, and input handling

import { LevelData, Player, QuestionTrigger, NPC } from '../types/game';
import { GameRenderer } from './renderer';
import { soundManager } from '../utils/audio';

export interface GameEngineCallbacks {
  onQuestionTrigger: (trigger: QuestionTrigger) => void;
  onNPCDialogue: (npc: NPC) => void;
  onLevelComplete: () => void;
  onCheckpointReached: (name: string) => void;
  onPlayerHurt: (remainingLives: number) => void;
  onCoinsChanged: (coins: number, score: number) => void;
  onExitLocked?: (completed: number, total: number) => void;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private renderer: GameRenderer;
  private callbacks: GameEngineCallbacks;

  public level: LevelData;
  public player: Player;
  public cameraX: number = 0;

  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private lastTime: number = 0;
  private animFrameId: number | null = null;
  private exitPromptCooldown: number = 0;

  // Respawn checkpoint
  private activeCheckpointPos: { x: number; y: number } = { x: 80, y: 540 };

  // Input states
  public keys: {
    left: boolean;
    right: boolean;
    jump: boolean;
    interact: boolean;
  } = {
    left: false,
    right: false,
    jump: false,
    interact: false,
  };

  constructor(
    canvas: HTMLCanvasElement,
    level: LevelData,
    callbacks: GameEngineCallbacks,
    initialCoins: number = 0,
    initialScore: number = 0
  ) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.renderer = new GameRenderer();
    this.level = JSON.parse(JSON.stringify(level)); // Deep copy to mutate coin/checkpoint states cleanly
    this.callbacks = callbacks;

    this.player = {
      x: 80,
      y: 540,
      vx: 0,
      vy: 0,
      width: 28,
      height: 48,
      facingLeft: false,
      isGrounded: false,
      isJumping: false,
      state: 'idle',
      stateTime: 0,
      invulnerableTime: 0,
      lives: 3,
      maxLives: 3,
      score: initialScore,
      coins: initialCoins,
    };

    this.activeCheckpointPos = { x: 80, y: 540 };
    this.setupKeyboardListeners();
  }

  private setupKeyboardListeners() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
  }

  public destroy() {
    this.stop();
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
      this.keys.left = true;
    } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
      this.keys.right = true;
    } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W' || e.key === ' ') {
      if (!this.keys.jump && this.player.isGrounded) {
        this.jump();
      }
      this.keys.jump = true;
    } else if (e.key === 'e' || e.key === 'E' || e.key === 'Enter') {
      this.keys.interact = true;
      this.checkManualInteraction();
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
      this.keys.left = false;
    } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
      this.keys.right = false;
    } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W' || e.key === ' ') {
      this.keys.jump = false;
    } else if (e.key === 'e' || e.key === 'E' || e.key === 'Enter') {
      this.keys.interact = false;
    }
  };

  public setTouchInput(action: 'left' | 'right' | 'jump' | 'interact', active: boolean) {
    if (action === 'left') this.keys.left = active;
    if (action === 'right') this.keys.right = active;
    if (action === 'jump') {
      if (active && !this.keys.jump && this.player.isGrounded) {
        this.jump();
      }
      this.keys.jump = active;
    }
    if (action === 'interact') {
      this.keys.interact = active;
      if (active) this.checkManualInteraction();
    }
  }

  public jump() {
    if (this.player.isGrounded) {
      this.player.vy = -12.5;
      this.player.isGrounded = false;
      this.player.isJumping = true;
      soundManager.playSFX('jump');
      this.renderer.addBurstParticles(this.player.x + 14, this.player.y + 48, '#e2e8f0', 5);
    }
  }

  public pause() {
    this.isPaused = true;
  }

  public resume() {
    this.isPaused = false;
    this.lastTime = performance.now();
  }

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.isPaused = false;
    this.lastTime = performance.now();
    soundManager.playBGM(this.level.id);

    const loop = (currentTime: number) => {
      if (!this.isRunning) return;

      const rawDt = (currentTime - this.lastTime) / 1000;
      this.lastTime = currentTime;
      const dt = Math.min(rawDt, 0.05); // Clamp dt to prevent tunneling on lag

      if (!this.isPaused) {
        this.update(dt);
      }
      this.render();

      this.animFrameId = requestAnimationFrame(loop);
    };

    this.animFrameId = requestAnimationFrame(loop);
  }

  public stop() {
    this.isRunning = false;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    soundManager.stopBGM();
  }

  // --- Physics & Logic Update ---
  private update(dt: number) {
    const p = this.player;
    const accel = 18;
    const friction = 0.82;
    const gravity = 26;

    // Horizontal Movement
    if (this.keys.left) {
      p.vx -= accel * dt;
      p.facingLeft = true;
    } else if (this.keys.right) {
      p.vx += accel * dt;
      p.facingLeft = false;
    } else {
      p.vx *= friction;
    }

    // Velocity limits
    const maxSpeed = 5.2;
    p.vx = Math.max(-maxSpeed, Math.min(maxSpeed, p.vx));

    // Vertical Movement (Gravity)
    p.vy += gravity * dt;
    if (p.vy > 14) p.vy = 14;

    // Moving platforms update
    for (const plat of this.level.platforms) {
      if (plat.type === 'moving' && plat.initialX !== undefined && plat.moveRange && plat.moveSpeed) {
        const time = performance.now() / 1000;
        const prevX = plat.x;
        plat.x = plat.initialX + Math.sin(time * plat.moveSpeed) * plat.moveRange;
        // If player is on this platform, carry them along
        if (p.isGrounded && p.y + p.height >= plat.y - 4 && p.y + p.height <= plat.y + 10 &&
            p.x + p.width > plat.x && p.x < plat.x + plat.width) {
          p.x += (plat.x - prevX);
        }
      }
    }

    // Attempt Horizontal Movement & Collision
    p.x += p.vx;
    this.resolveHorizontalCollisions();

    // Attempt Vertical Movement & Collision
    p.isGrounded = false;
    p.y += p.vy;
    this.resolveVerticalCollisions();

    // Invulnerability cooldown
    if (p.invulnerableTime > 0) {
      p.invulnerableTime = Math.max(0, p.invulnerableTime - dt);
    }

    if (this.exitPromptCooldown > 0) {
      this.exitPromptCooldown = Math.max(0, this.exitPromptCooldown - dt);
    }

    // State machine for animation
    if (!p.isGrounded) {
      p.state = p.vy < 0 ? 'jumping' : 'falling';
    } else if (Math.abs(p.vx) > 0.4) {
      p.state = 'running';
    } else {
      p.state = 'idle';
    }

    // World Boundaries
    if (p.x < 10) {
      p.x = 10;
      p.vx = 0;
    }
    if (p.x > this.level.worldWidth - p.width - 10) {
      p.x = this.level.worldWidth - p.width - 10;
      p.vx = 0;
    }

    // Pit Fall Check
    if (p.y > this.level.worldHeight + 80) {
      this.handleDamage(true);
    }

    // Update triggers & interactions
    this.checkCoins();
    this.checkObstacles();
    this.checkCheckpoints();
    this.checkAutomaticQuestionTriggers();
    this.checkExit();

    // Smooth Camera Following
    const targetCameraX = p.x - this.canvas.width * 0.38;
    this.cameraX += (targetCameraX - this.cameraX) * 0.12;
    this.cameraX = Math.max(0, Math.min(this.level.worldWidth - this.canvas.width, this.cameraX));

    // Update particles & animations
    this.renderer.update(dt);
  }

  // --- Collision Resolutions ---
  private resolveHorizontalCollisions() {
    const p = this.player;
    for (const plat of this.level.platforms) {
      if (this.checkAABB(p.x, p.y, p.width, p.height, plat.x, plat.y, plat.width, plat.height)) {
        if (p.vx > 0) {
          p.x = plat.x - p.width;
          p.vx = 0;
        } else if (p.vx < 0) {
          p.x = plat.x + plat.width;
          p.vx = 0;
        }
      }
    }
  }

  private resolveVerticalCollisions() {
    const p = this.player;
    for (const plat of this.level.platforms) {
      if (this.checkAABB(p.x, p.y, p.width, p.height, plat.x, plat.y, plat.width, plat.height)) {
        if (p.vy > 0) {
          // Landing on top of platform
          p.y = plat.y - p.height;
          p.vy = 0;
          p.isGrounded = true;
          p.isJumping = false;
        } else if (p.vy < 0) {
          // Hitting ceiling
          p.y = plat.y + plat.height;
          p.vy = 0;
        }
      }
    }
  }

  private checkAABB(
    x1: number, y1: number, w1: number, h1: number,
    x2: number, y2: number, w2: number, h2: number
  ): boolean {
    return x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2;
  }

  // --- Coin Collection ---
  private checkCoins() {
    const p = this.player;
    for (const coin of this.level.coins) {
      if (coin.collected) continue;
      const dist = Math.hypot(p.x + p.width / 2 - coin.x, p.y + p.height / 2 - coin.y);
      if (dist < 26) {
        coin.collected = true;
        p.coins += 1;
        p.score += 20;
        soundManager.playSFX('coin');
        this.renderer.addBurstParticles(coin.x, coin.y, '#facc15', 10);
        this.callbacks.onCoinsChanged(p.coins, p.score);
      }
    }
  }

  // --- Obstacles & Hazard Collision ---
  private checkObstacles() {
    if (this.player.invulnerableTime > 0) return;
    const p = this.player;

    for (const obs of this.level.obstacles) {
      if (this.checkAABB(p.x, p.y, p.width, p.height, obs.x, obs.y, obs.width, obs.height)) {
        this.handleDamage(false);
        break;
      }
    }
  }

  private handleDamage(isPit: boolean) {
    const p = this.player;
    p.lives -= 1;
    soundManager.playSFX('hurt');
    this.renderer.addBurstParticles(p.x + 14, p.y + 24, '#ef4444', 14);

    this.callbacks.onPlayerHurt(p.lives);

    if (p.lives <= 0) {
      // Graceful respawn at active checkpoint with replenished hearts
      p.lives = 3;
      p.x = this.activeCheckpointPos.x;
      p.y = this.activeCheckpointPos.y;
      p.vx = 0;
      p.vy = 0;
      p.invulnerableTime = 1.5;
    } else {
      if (isPit) {
        p.x = this.activeCheckpointPos.x;
        p.y = this.activeCheckpointPos.y;
        p.vx = 0;
        p.vy = 0;
      } else {
        // Small knockback recoil
        p.vy = -6;
        p.vx = p.facingLeft ? 4 : -4;
        p.invulnerableTime = 1.2;
      }
    }
  }

  // --- Checkpoints ---
  private checkCheckpoints() {
    const p = this.player;
    for (const cp of this.level.checkpoints) {
      if (cp.reached) continue;
      if (p.x >= cp.x - 20 && p.x <= cp.x + 40 && Math.abs(p.y - (cp.y - 48)) < 60) {
        cp.reached = true;
        this.activeCheckpointPos = { x: cp.x, y: cp.y - p.height };
        soundManager.playSFX('checkpoint');
        this.renderer.addBurstParticles(cp.x + 10, cp.y - 50, '#10b981', 16);
        this.callbacks.onCheckpointReached(cp.name);
      }
    }
  }

  // --- Question Trigger Automatic Sensing ---
  private checkAutomaticQuestionTriggers() {
    const p = this.player;
    for (const qt of this.level.questionTriggers) {
      if (qt.triggered) continue;
      if (this.checkAABB(p.x, p.y, p.width, p.height, qt.x, qt.y - 30, qt.width, qt.height + 30)) {
        this.pause();
        this.callbacks.onQuestionTrigger(qt);
        break;
      }
    }
  }

  // --- Manual NPC / Inspect Interaction ---
  private checkManualInteraction() {
    const p = this.player;
    for (const npc of this.level.npcs) {
      const dist = Math.abs(p.x - npc.x);
      if (dist < 80) {
        soundManager.playSFX('dialogue');
        this.pause();
        this.callbacks.onNPCDialogue(npc);
        break;
      }
    }
  }

  // --- Exit Reached ---
  private checkExit() {
    const p = this.player;
    const ex = this.level.exit;
    if (this.checkAABB(p.x, p.y, p.width, p.height, ex.x, ex.y, ex.width, ex.height)) {
      // Check if all question triggers are answered
      const completedCount = this.level.questionTriggers.filter((q) => q.triggered).length;
      const totalCount = this.level.questionTriggers.length;

      if (completedCount >= totalCount) {
        p.state = 'winning';
        p.vx = 0;
        this.stop();
        soundManager.playSFX('level_clear');
        this.callbacks.onLevelComplete();
      } else {
        if (this.exitPromptCooldown <= 0) {
          this.exitPromptCooldown = 2.5;
          soundManager.playSFX('dialogue');
          this.callbacks.onExitLocked?.(completedCount, totalCount);
        }
      }
    }
  }

  // --- Render Frame ---
  private render() {
    this.renderer.render(
      this.ctx,
      this.canvas.width,
      this.canvas.height,
      this.cameraX,
      this.level,
      this.player
    );
  }
}
