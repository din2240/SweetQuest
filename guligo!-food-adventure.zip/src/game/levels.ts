// Detailed level configurations for GULIGO! FOOD ADVENTURE
// All player-facing names, subtitles, NPC dialogues in natural Indonesian

import { LevelData } from '../types/game';

export const LEVELS: LevelData[] = [
  // ==========================================
  // LEVEL 1: LEMBAH MINUMAN MANIS
  // ==========================================
  {
    id: 1,
    name: 'Level 1',
    title: 'Lembah Minuman Manis',
    subtitle: 'Mengenal Minuman Manis & Air Putih Segar',
    learningFocus: 'Mengenal Minuman Manis',
    worldWidth: 3200,
    worldHeight: 700,
    theme: 'valley',
    skyColors: ['#fce7f3', '#fdf4ff'], // Soft pastel strawberry pink to lavender mist
    groundColor: '#4ade80', // Lush strawberry mint green
    platforms: [
      // Ground stretches
      { x: 0, y: 620, width: 850, height: 80, type: 'ground' },
      { x: 920, y: 620, width: 700, height: 80, type: 'ground' },
      { x: 1700, y: 620, width: 750, height: 80, type: 'ground' },
      { x: 2520, y: 620, width: 680, height: 80, type: 'ground' },

      // Elevated grassy hills & wooden bridges
      { x: 260, y: 520, width: 140, height: 26, type: 'wood' },
      { x: 460, y: 440, width: 160, height: 26, type: 'wood' },
      { x: 680, y: 380, width: 130, height: 26, type: 'leaf' },

      // River bridge
      { x: 840, y: 580, width: 90, height: 24, type: 'wood' },

      // Middle section
      { x: 1040, y: 510, width: 150, height: 26, type: 'wood' },
      { x: 1250, y: 430, width: 140, height: 26, type: 'leaf' },
      { x: 1450, y: 360, width: 150, height: 26, type: 'wood' },

      // Moving platform over valley gap
      { x: 1610, y: 530, width: 100, height: 24, type: 'moving', initialX: 1610, moveRange: 130, moveSpeed: 1.2 },

      // Hill platforms near checkpoint
      { x: 1850, y: 510, width: 160, height: 26, type: 'wood' },
      { x: 2070, y: 420, width: 150, height: 26, type: 'leaf' },
      { x: 2280, y: 340, width: 140, height: 26, type: 'wood' },

      // Final approach
      { x: 2430, y: 570, width: 100, height: 24, type: 'wood' },
      { x: 2700, y: 510, width: 160, height: 26, type: 'leaf' },
      { x: 2920, y: 430, width: 180, height: 26, type: 'wood' },
    ],
    coins: [
      { id: 'c1-1', x: 200, y: 580, collected: false, bobOffset: 0 },
      { id: 'c1-2', x: 300, y: 480, collected: false, bobOffset: 0.5 },
      { id: 'c1-3', x: 500, y: 400, collected: false, bobOffset: 1.0 },
      { id: 'c1-4', x: 720, y: 340, collected: false, bobOffset: 1.5 },
      { id: 'c1-5', x: 880, y: 540, collected: false, bobOffset: 2.0 },
      { id: 'c1-6', x: 1100, y: 470, collected: false, bobOffset: 0.2 },
      { id: 'c1-7', x: 1300, y: 390, collected: false, bobOffset: 0.8 },
      { id: 'c1-8', x: 1500, y: 320, collected: false, bobOffset: 1.4 },
      { id: 'c1-9', x: 1660, y: 490, collected: false, bobOffset: 1.9 },
      { id: 'c1-10', x: 1900, y: 470, collected: false, bobOffset: 0.3 },
      { id: 'c1-11', x: 2120, y: 380, collected: false, bobOffset: 0.9 },
      { id: 'c1-12', x: 2330, y: 300, collected: false, bobOffset: 1.6 },
      { id: 'c1-13', x: 2750, y: 470, collected: false, bobOffset: 0.4 },
      { id: 'c1-14', x: 2970, y: 390, collected: false, bobOffset: 1.1 },
      { id: 'c1-15', x: 3050, y: 580, collected: false, bobOffset: 1.7 },
    ],
    obstacles: [
      // Sweet sticky mud puddles
      { id: 'obs-1', x: 580, y: 605, width: 60, height: 16, type: 'mud' },
      { id: 'obs-2', x: 1180, y: 605, width: 70, height: 16, type: 'mud' },
      { id: 'obs-3', x: 2000, y: 605, width: 60, height: 16, type: 'mud' },
      { id: 'obs-4', x: 2620, y: 605, width: 80, height: 16, type: 'mud' },
    ],
    checkpoints: [
      { id: 'cp-1', x: 1720, y: 620, reached: false, name: 'Pos Lembah Tengah' },
    ],
    questionTriggers: [
      { id: 'qt-1', x: 690, y: 380, width: 44, height: 50, questionId: 'MM-01', triggered: false },
      { id: 'qt-2', x: 1460, y: 360, width: 44, height: 50, questionId: 'MM-02', triggered: false },
      { id: 'qt-3', x: 2290, y: 340, width: 44, height: 50, questionId: 'MM-03', triggered: false },
      { id: 'qt-4', x: 2930, y: 430, width: 44, height: 50, questionId: 'MM-05', triggered: false },
    ],
    npcs: [
      {
        id: 'npc-1',
        name: 'Pak Tani Arif',
        title: 'Petani Kebun Segar',
        avatar: 'pak_arif',
        x: 360,
        y: 620,
        dialogue: [
          'Halo petualang cilik! Selamat datang di Lembah Minuman Manis.',
          'Saat berpetualang dan berlari, tubuh kita banyak kehilangan cairan lewat keringat.',
          'Ingat ya, air putih selalu menjadi pilihan nomor satu untuk meredakan dahaga dan menjaga konsentrasi belajar!',
          'Kumpulkan koin dan sentuh Tugu Pengetahuan untuk menjawab pertanyaan!'
        ],
      },
    ],
    exit: { x: 3100, y: 540, width: 60, height: 80 },
  },

  // ==========================================
  // LEVEL 2: HUTAN MAKANAN MANIS
  // ==========================================
  {
    id: 2,
    name: 'Level 2',
    title: 'Hutan Makanan Manis',
    subtitle: 'Mengenal Makanan Manis & Membaca Informasi Gizi',
    learningFocus: 'Mengenal Makanan Manis & Membaca Informasi Gizi',
    worldWidth: 3600,
    worldHeight: 700,
    theme: 'forest',
    skyColors: ['#fbcfe8', '#ede9fe'], // Pastel rose pink to lavender sky
    groundColor: '#2dd4bf',
    platforms: [
      // Ground stretches
      { x: 0, y: 620, width: 750, height: 80, type: 'ground' },
      { x: 840, y: 620, width: 800, height: 80, type: 'ground' },
      { x: 1720, y: 620, width: 820, height: 80, type: 'ground' },
      { x: 2620, y: 620, width: 980, height: 80, type: 'ground' },

      // Giant mushroom & moss platforms
      { x: 240, y: 510, width: 140, height: 26, type: 'leaf' },
      { x: 440, y: 420, width: 150, height: 26, type: 'leaf' },
      { x: 640, y: 340, width: 140, height: 26, type: 'leaf' },

      // Floating log bridge
      { x: 760, y: 560, width: 90, height: 22, type: 'wood' },

      // Middle forest canopy
      { x: 960, y: 490, width: 150, height: 26, type: 'leaf' },
      { x: 1180, y: 400, width: 150, height: 26, type: 'wood' },
      { x: 1390, y: 320, width: 140, height: 26, type: 'leaf' },

      // Moving platform over syrup pond
      { x: 1570, y: 500, width: 110, height: 24, type: 'moving', initialX: 1570, moveRange: 140, moveSpeed: 1.5 },

      // Treehouse branch platforms
      { x: 1880, y: 490, width: 160, height: 26, type: 'leaf' },
      { x: 2110, y: 410, width: 150, height: 26, type: 'wood' },
      { x: 2320, y: 330, width: 140, height: 26, type: 'leaf' },

      // High treetop route
      { x: 2510, y: 560, width: 100, height: 24, type: 'wood' },
      { x: 2750, y: 490, width: 160, height: 26, type: 'leaf' },
      { x: 2980, y: 410, width: 160, height: 26, type: 'wood' },
      { x: 3220, y: 330, width: 150, height: 26, type: 'leaf' },
    ],
    coins: [
      { id: 'c2-1', x: 180, y: 580, collected: false, bobOffset: 0 },
      { id: 'c2-2', x: 280, y: 470, collected: false, bobOffset: 0.4 },
      { id: 'c2-3', x: 480, y: 380, collected: false, bobOffset: 0.9 },
      { id: 'c2-4', x: 680, y: 300, collected: false, bobOffset: 1.3 },
      { id: 'c2-5', x: 800, y: 520, collected: false, bobOffset: 1.7 },
      { id: 'c2-6', x: 1020, y: 450, collected: false, bobOffset: 0.3 },
      { id: 'c2-7', x: 1240, y: 360, collected: false, bobOffset: 0.8 },
      { id: 'c2-8', x: 1440, y: 280, collected: false, bobOffset: 1.4 },
      { id: 'c2-9', x: 1630, y: 460, collected: false, bobOffset: 1.8 },
      { id: 'c2-10', x: 1940, y: 450, collected: false, bobOffset: 0.2 },
      { id: 'c2-11', x: 2160, y: 370, collected: false, bobOffset: 0.7 },
      { id: 'c2-12', x: 2370, y: 290, collected: false, bobOffset: 1.2 },
      { id: 'c2-13', x: 2800, y: 450, collected: false, bobOffset: 0.5 },
      { id: 'c2-14', x: 3030, y: 370, collected: false, bobOffset: 1.0 },
      { id: 'c2-15', x: 3270, y: 290, collected: false, bobOffset: 1.5 },
      { id: 'c2-16', x: 3450, y: 580, collected: false, bobOffset: 2.0 },
    ],
    obstacles: [
      // Sweet syrup hazards
      { id: 'obs-2-1', x: 520, y: 605, width: 70, height: 16, type: 'syrup' },
      { id: 'obs-2-2', x: 1280, y: 605, width: 80, height: 16, type: 'syrup' },
      { id: 'obs-2-3', x: 2020, y: 605, width: 70, height: 16, type: 'syrup' },
      { id: 'obs-2-4', x: 2900, y: 605, width: 80, height: 16, type: 'syrup' },
    ],
    checkpoints: [
      { id: 'cp-2', x: 1740, y: 620, reached: false, name: 'Lentera Hutan Tengah' },
    ],
    questionTriggers: [
      { id: 'qt-2-1', x: 650, y: 340, width: 44, height: 50, questionId: 'MK-01', triggered: false },
      { id: 'qt-2-2', x: 1400, y: 320, width: 44, height: 50, questionId: 'MK-02', triggered: false },
      { id: 'qt-2-3', x: 2330, y: 330, width: 44, height: 50, questionId: 'IG-01', triggered: false },
      { id: 'qt-2-4', x: 3230, y: 330, width: 44, height: 50, questionId: 'IG-04', triggered: false },
    ],
    npcs: [
      {
        id: 'npc-2',
        name: 'Koki Ratna',
        title: 'Pakar Masakan Sehat',
        avatar: 'koki_ratna',
        x: 350,
        y: 620,
        dialogue: [
          'Salam hangat, penjelajah cilik! Saya Koki Ratna.',
          'Di hutan ini, banyak camilan yang terlihat manis dan menggoda.',
          'Namun jangan terkecoh oleh kemasan yang berkilau! Biasakan membalik kemasan dan membaca tabel informasi nilai gizi.',
          'Bandingkan jumlah gram gula sebelum memilih camilan sehari-hari ya!'
        ],
      },
    ],
    exit: { x: 3500, y: 540, width: 60, height: 80 },
  },

  // ==========================================
  // LEVEL 3: ISTANA PILIHAN SEHAT
  // ==========================================
  {
    id: 3,
    name: 'Level 3',
    title: 'Istana Pilihan Sehat',
    subtitle: 'Gula, Tubuhku, & Keputusan Makanan yang Bijak',
    learningFocus: 'Gula dan Tubuhku serta Pilihan Makanan yang Bijak',
    worldWidth: 4000,
    worldHeight: 700,
    theme: 'castle',
    skyColors: ['#f5d0fe', '#fae8ff'], // Soft lavender royal glow
    groundColor: '#c084fc',
    platforms: [
      // Palace courtyard ground
      { x: 0, y: 620, width: 800, height: 80, type: 'ground' },
      { x: 880, y: 620, width: 850, height: 80, type: 'ground' },
      { x: 1820, y: 620, width: 900, height: 80, type: 'ground' },
      { x: 2800, y: 620, width: 1200, height: 80, type: 'ground' },

      // Palace marble pillars & crystal terraces
      { x: 260, y: 500, width: 150, height: 26, type: 'stone' },
      { x: 480, y: 410, width: 160, height: 26, type: 'crystal' },
      { x: 700, y: 320, width: 140, height: 26, type: 'stone' },

      // Royal bridge
      { x: 810, y: 560, width: 85, height: 24, type: 'stone' },

      // Throne room pillars
      { x: 1020, y: 480, width: 150, height: 26, type: 'crystal' },
      { x: 1240, y: 390, width: 150, height: 26, type: 'stone' },
      { x: 1460, y: 310, width: 150, height: 26, type: 'crystal' },

      // Moving royal terrace
      { x: 1660, y: 490, width: 120, height: 24, type: 'moving', initialX: 1660, moveRange: 150, moveSpeed: 1.6 },

      // Castle garden towers
      { x: 1960, y: 480, width: 160, height: 26, type: 'stone' },
      { x: 2190, y: 390, width: 150, height: 26, type: 'crystal' },
      { x: 2420, y: 300, width: 150, height: 26, type: 'stone' },

      // Floating crystal clouds
      { x: 2630, y: 550, width: 100, height: 24, type: 'crystal' },
      { x: 2880, y: 470, width: 160, height: 26, type: 'stone' },
      { x: 3110, y: 380, width: 160, height: 26, type: 'crystal' },
      { x: 3340, y: 290, width: 150, height: 26, type: 'stone' },
      { x: 3580, y: 390, width: 180, height: 26, type: 'crystal' },
    ],
    coins: [
      { id: 'c3-1', x: 200, y: 580, collected: false, bobOffset: 0 },
      { id: 'c3-2', x: 310, y: 460, collected: false, bobOffset: 0.3 },
      { id: 'c3-3', x: 530, y: 370, collected: false, bobOffset: 0.7 },
      { id: 'c3-4', x: 740, y: 280, collected: false, bobOffset: 1.2 },
      { id: 'c3-5', x: 840, y: 520, collected: false, bobOffset: 1.6 },
      { id: 'c3-6', x: 1080, y: 440, collected: false, bobOffset: 0.4 },
      { id: 'c3-7', x: 1300, y: 350, collected: false, bobOffset: 0.9 },
      { id: 'c3-8', x: 1510, y: 270, collected: false, bobOffset: 1.5 },
      { id: 'c3-9', x: 1720, y: 450, collected: false, bobOffset: 1.9 },
      { id: 'c3-10', x: 2020, y: 440, collected: false, bobOffset: 0.3 },
      { id: 'c3-11', x: 2240, y: 350, collected: false, bobOffset: 0.8 },
      { id: 'c3-12', x: 2470, y: 260, collected: false, bobOffset: 1.3 },
      { id: 'c3-13', x: 2930, y: 430, collected: false, bobOffset: 0.5 },
      { id: 'c3-14', x: 3160, y: 340, collected: false, bobOffset: 1.0 },
      { id: 'c3-15', x: 3390, y: 250, collected: false, bobOffset: 1.6 },
      { id: 'c3-16', x: 3630, y: 350, collected: false, bobOffset: 0.2 },
      { id: 'c3-17', x: 3820, y: 580, collected: false, bobOffset: 0.8 },
    ],
    obstacles: [
      // Sweet crystal brambles / candy pops
      { id: 'obs-3-1', x: 550, y: 605, width: 70, height: 16, type: 'candy_pop' },
      { id: 'obs-3-2', x: 1360, y: 605, width: 80, height: 16, type: 'candy_pop' },
      { id: 'obs-3-3', x: 2120, y: 605, width: 75, height: 16, type: 'candy_pop' },
      { id: 'obs-3-4', x: 3020, y: 605, width: 85, height: 16, type: 'candy_pop' },
    ],
    checkpoints: [
      { id: 'cp-3', x: 1840, y: 620, reached: false, name: 'Air Mancur Istana' },
    ],
    questionTriggers: [
      { id: 'qt-3-1', x: 710, y: 320, width: 44, height: 50, questionId: 'GT-01', triggered: false },
      { id: 'qt-3-2', x: 1470, y: 310, width: 44, height: 50, questionId: 'GT-02', triggered: false },
      { id: 'qt-3-3', x: 2430, y: 300, width: 44, height: 50, questionId: 'GT-03', triggered: false },
      { id: 'qt-3-4', x: 3350, y: 290, width: 44, height: 50, questionId: 'PB-01', triggered: false },
      { id: 'qt-3-5', x: 3600, y: 390, width: 44, height: 50, questionId: 'PB-05', triggered: false },
    ],
    npcs: [
      {
        id: 'npc-3',
        name: 'Dokter Gita',
        title: 'Sahabat Kesehatan Anak',
        avatar: 'dokter_gita',
        x: 380,
        y: 620,
        dialogue: [
          'Selamat datang di Istana Pilihan Sehat! Saya Dokter Gita.',
          'Tubuh kita adalah mahkota berharga yang harus kita rawat setiap hari.',
          'Gula memberikan rasa manis, namun jika dikonsumsi berlebihan dapat merusak gigi dan mengurangi kebugaran.',
          'Tunjukkan bahwa kamu adalah Penjelajah Bijak yang siap memilih makanan sehat dan seimbang!'
        ],
      },
    ],
    exit: { x: 3900, y: 540, width: 60, height: 80 },
  },
];
