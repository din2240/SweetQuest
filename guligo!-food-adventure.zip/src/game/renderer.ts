// Visual renderer for SweetQuest
// High-fidelity procedural 2D Canvas rendering inspired by the Strawberry Shortcake aesthetic
// Soft pastel pinks, strawberry reds, lavender purples, cute cartoon protagonist, and whimsical berry fantasy scenery.

import { LevelData, Player } from '../types/game';

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
}

export class GameRenderer {
  private particles: Particle[] = [];
  private ambientParticles: Particle[] = [];
  private animTimer: number = 0;

  constructor() {
    this.initAmbientParticles();
  }

  private initAmbientParticles() {
    this.ambientParticles = [];
    // Drifting strawberry petals & golden sparkles
    for (let i = 0; i < 40; i++) {
      this.ambientParticles.push({
        x: Math.random() * 4000,
        y: Math.random() * 700,
        vx: (Math.random() - 0.5) * 0.5 - 0.2,
        vy: (Math.random() - 0.5) * 0.3 + 0.1,
        size: Math.random() * 3 + 2,
        color: Math.random() > 0.5 ? '#fbcfe8' : '#e9d5ff',
        alpha: Math.random() * 0.6 + 0.2,
        life: 1,
        maxLife: 1,
      });
    }
  }

  public addBurstParticles(x: number, y: number, color: string = '#f472b6', count: number = 14) {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.5;
      const speed = Math.random() * 3 + 2;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1.5,
        size: Math.random() * 4 + 2,
        color,
        alpha: 1,
        life: 0,
        maxLife: 28,
      });
    }
  }

  public update(dt: number) {
    this.animTimer += dt;

    // Update burst particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.12; // gentle gravity
      p.life += 1;
      p.alpha = Math.max(0, 1 - p.life / p.maxLife);
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
      }
    }

    // Update ambient particles
    for (const p of this.ambientParticles) {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = 4000;
      if (p.x > 4000) p.x = 0;
      if (p.y < 0) p.y = 700;
      if (p.y > 700) p.y = 0;
    }
  }

  public render(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    cameraX: number,
    level: LevelData,
    player: Player
  ) {
    ctx.save();

    // 1. Sky Gradient Background (Soft pastel pink to cream/lavender)
    const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
    skyGrad.addColorStop(0, level.skyColors[0]);
    skyGrad.addColorStop(1, level.skyColors[1]);
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, width, height);

    // 2. Parallax Distant Layer (Soft lavender strawberry hills & puffy clouds)
    this.renderFarParallax(ctx, width, height, cameraX);

    // 3. Parallax Midground Layer (Strawberry cottages, giant berry plants, cake trees)
    this.renderMidParallax(ctx, width, height, cameraX, level);

    // Apply Camera Transform for World Objects
    ctx.save();
    ctx.translate(-cameraX, 0);

    // 4. Ambient Environmental Elements
    this.renderEnvironmentalDetails(ctx, cameraX, width);

    // 5. Platforms & Ground
    this.renderPlatforms(ctx, level);

    // 6. Obstacles
    this.renderObstacles(ctx, level);

    // 7. Checkpoints
    this.renderCheckpoints(ctx, level);

    // 8. Question Shrines (Tugu Pengetahuan Stroberi)
    this.renderQuestionTriggers(ctx, level);

    // 9. Collectible Coins
    this.renderCoins(ctx, level);

    // 10. NPCs
    this.renderNPCs(ctx, level, player);

    // 11. Level Exit (Gerbang Rumah Kue Stroberi)
    this.renderExit(ctx, level);

    // 12. Protagonist (Strawberry Shortcake inspired adorable cartoon hero)
    this.renderPlayer(ctx, player);

    // 13. Particles
    this.renderParticles(ctx);

    ctx.restore(); // Restore camera
    ctx.restore(); // Restore root
  }

  // --- Parallax Backgrounds ---
  private renderFarParallax(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    cameraX: number
  ) {
    const shift = cameraX * 0.15;

    // Distant pastel lavender hills
    ctx.fillStyle = '#f5d0fe';
    ctx.beginPath();
    ctx.moveTo(0, height);
    for (let x = -200; x <= width + 200; x += 180) {
      const worldX = x + (shift % 360);
      const h = Math.sin(worldX * 0.005) * 70 + 320;
      ctx.lineTo(x, height - h);
    }
    ctx.lineTo(width, height);
    ctx.closePath();
    ctx.fill();

    // Secondary soft strawberry pink mountain range
    ctx.fillStyle = '#fbcfe8';
    ctx.beginPath();
    ctx.moveTo(0, height);
    for (let x = -150; x <= width + 150; x += 150) {
      const worldX = x + (shift * 1.2 % 300);
      const h = Math.cos(worldX * 0.006) * 50 + 260;
      ctx.lineTo(x, height - h);
    }
    ctx.lineTo(width, height);
    ctx.closePath();
    ctx.fill();

    // Drifting cotton-candy clouds with soft strawberry pink highlight
    for (let i = 0; i < 6; i++) {
      const cx = ((i * 320 - shift * 0.5 + this.animTimer * 10) % (width + 400)) - 100;
      const cy = 60 + (i % 3) * 45;
      this.drawCloud(ctx, cx, cy, 50 + (i % 2) * 20);
    }
  }

  private drawCloud(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
    ctx.fillStyle = 'rgba(255, 245, 250, 0.9)';
    ctx.beginPath();
    ctx.arc(x, y, r * 0.6, 0, Math.PI * 2);
    ctx.arc(x + r * 0.45, y - r * 0.25, r * 0.5, 0, Math.PI * 2);
    ctx.arc(x + r * 0.9, y, r * 0.55, 0, Math.PI * 2);
    ctx.arc(x + r * 0.45, y + r * 0.1, r * 0.4, 0, Math.PI * 2);
    ctx.fill();

    // Gentle pink cloud shading
    ctx.fillStyle = 'rgba(251, 207, 232, 0.4)';
    ctx.beginPath();
    ctx.arc(x + r * 0.45, y + r * 0.1, r * 0.35, 0, Math.PI);
    ctx.fill();
  }

  private renderMidParallax(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    cameraX: number,
    level: LevelData
  ) {
    const shift = cameraX * 0.35;

    // Rolling mint-green and pastel pink midground knolls
    ctx.fillStyle = '#bbf7d0';
    ctx.beginPath();
    ctx.moveTo(0, height);
    for (let x = -100; x <= width + 100; x += 120) {
      const worldX = x + (shift % 240);
      const h = Math.cos(worldX * 0.008) * 50 + 220;
      ctx.lineTo(x, height - h);
    }
    ctx.lineTo(width, height);
    ctx.closePath();
    ctx.fill();

    // Midground strawberry cottages, candy flowers, and cake trees
    for (let i = 0; i < 7; i++) {
      const tx = ((i * 280 - shift) % (width + 300)) - 50;
      const ty = height - 190;

      if (level.theme === 'valley') {
        // Cute strawberry cottage with green roof
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.roundRect(tx + 5, ty - 45, 34, 45, [14, 14, 4, 4]);
        ctx.fill();

        // Strawberry seeds
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(tx + 14, ty - 30, 1.2, 0, Math.PI * 2);
        ctx.arc(tx + 28, ty - 30, 1.2, 0, Math.PI * 2);
        ctx.arc(tx + 21, ty - 18, 1.2, 0, Math.PI * 2);
        ctx.fill();

        // Green leafy roof calyx
        ctx.fillStyle = '#4ade80';
        ctx.beginPath();
        ctx.ellipse(tx + 22, ty - 45, 20, 6, 0, 0, Math.PI * 2);
        ctx.fill();

        // Little white door
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.roundRect(tx + 16, ty - 18, 12, 18, [6, 6, 0, 0]);
        ctx.fill();
      } else if (level.theme === 'forest') {
        // Giant frosted cupcake tree
        ctx.fillStyle = '#e9d5ff';
        ctx.beginPath();
        ctx.arc(tx + 22, ty - 40, 26, 0, Math.PI * 2);
        ctx.fill();

        // Strawberry cherry on top
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(tx + 22, ty - 64, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#4ade80';
        ctx.fillRect(tx + 21, ty - 73, 2, 9);
      } else {
        // Pastel lavender castle tower
        ctx.fillStyle = '#c084fc';
        ctx.fillRect(tx + 8, ty - 55, 26, 55);

        // Pink cone roof
        ctx.fillStyle = '#f472b6';
        ctx.beginPath();
        ctx.moveTo(tx + 4, ty - 55);
        ctx.lineTo(tx + 21, ty - 85);
        ctx.lineTo(tx + 38, ty - 55);
        ctx.closePath();
        ctx.fill();
      }
    }
  }

  private renderEnvironmentalDetails(
    ctx: CanvasRenderingContext2D,
    cameraX: number,
    width: number
  ) {
    // Ambient floating pastel petals
    for (const p of this.ambientParticles) {
      if (p.x >= cameraX - 50 && p.x <= cameraX + width + 50) {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  }

  // --- Platforms ---
  private renderPlatforms(ctx: CanvasRenderingContext2D, level: LevelData) {
    for (const plat of level.platforms) {
      if (plat.type === 'ground') {
        // Soft cookie crust base
        const soilGrad = ctx.createLinearGradient(0, plat.y, 0, plat.y + plat.height);
        soilGrad.addColorStop(0, '#fbcfe8');
        soilGrad.addColorStop(1, '#f472b6');
        ctx.fillStyle = soilGrad;
        ctx.fillRect(plat.x, plat.y + 14, plat.width, plat.height - 14);

        // Lush mint-green grass/strawberry leaf cap
        ctx.fillStyle = level.groundColor;
        ctx.beginPath();
        ctx.roundRect(plat.x, plat.y, plat.width, 18, [6, 6, 0, 0]);
        ctx.fill();

        // Cute scalloped leaf edges with tiny white strawberry blossoms
        ctx.fillStyle = level.groundColor;
        for (let gx = plat.x + 8; gx < plat.x + plat.width - 12; gx += 20) {
          ctx.beginPath();
          ctx.arc(gx + 6, plat.y + 18, 6, 0, Math.PI);
          ctx.fill();

          // Tiny white strawberry flower blossom
          if (gx % 40 === 8) {
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(gx + 6, plat.y + 10, 3, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#fef08a';
            ctx.beginPath();
            ctx.arc(gx + 6, plat.y + 10, 1.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = level.groundColor; // restore
          }
        }
      } else if (plat.type === 'wood' || plat.type === 'moving') {
        // Pastel biscuit wafer bridge
        ctx.fillStyle = plat.type === 'moving' ? '#f472b6' : '#fed7aa';
        ctx.beginPath();
        ctx.roundRect(plat.x, plat.y, plat.width, plat.height, 8);
        ctx.fill();

        // White sugar glaze trim on top
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(plat.x + 3, plat.y + 2, plat.width - 6, 3.5);

        // Wafer grid lines
        ctx.strokeStyle = plat.type === 'moving' ? '#db2777' : '#f97316';
        ctx.lineWidth = 1.2;
        for (let px = plat.x + 28; px < plat.x + plat.width - 8; px += 28) {
          ctx.beginPath();
          ctx.moveTo(px, plat.y);
          ctx.lineTo(px, plat.y + plat.height);
          ctx.stroke();
        }

        if (plat.type === 'moving') {
          // Cute strawberry decoration on moving lift
          ctx.fillStyle = '#f43f5e';
          ctx.beginPath();
          ctx.arc(plat.x + plat.width / 2, plat.y + plat.height / 2, 5, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#4ade80';
          ctx.fillRect(plat.x + plat.width / 2 - 1, plat.y + 1, 2, 4);
        }
      } else if (plat.type === 'leaf') {
        // Giant curved green strawberry leaf
        ctx.fillStyle = '#4ade80';
        ctx.beginPath();
        ctx.ellipse(plat.x + plat.width / 2, plat.y + plat.height / 2, plat.width / 2, plat.height / 1.3, 0, 0, Math.PI * 2);
        ctx.fill();

        // Pink leaf vein highlight
        ctx.strokeStyle = '#fbcfe8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(plat.x + 10, plat.y + plat.height / 2);
        ctx.lineTo(plat.x + plat.width - 10, plat.y + plat.height / 2);
        ctx.stroke();
      } else if (plat.type === 'stone' || plat.type === 'crystal') {
        // Sweet pastel lavender rock candy platform
        ctx.fillStyle = plat.type === 'crystal' ? '#d8b4fe' : '#f5d0fe';
        ctx.beginPath();
        ctx.roundRect(plat.x, plat.y, plat.width, plat.height, 8);
        ctx.fill();

        // Strawberry-pink border
        ctx.strokeStyle = '#f472b6';
        ctx.lineWidth = 2;
        ctx.strokeRect(plat.x + 2, plat.y + 2, plat.width - 4, plat.height - 4);
      }
    }
  }

  // --- Obstacles ---
  private renderObstacles(ctx: CanvasRenderingContext2D, level: LevelData) {
    for (const obs of level.obstacles) {
      if (obs.type === 'mud' || obs.type === 'syrup') {
        // Strawberry syrup puddle with glints
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.ellipse(obs.x + obs.width / 2, obs.y + obs.height / 2, obs.width / 2, obs.height / 2, 0, 0, Math.PI * 2);
        ctx.fill();

        // Glistening animated glints
        const bubbleY = obs.y + 2 + Math.sin(this.animTimer * 5 + obs.x) * 3;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(obs.x + obs.width * 0.35, bubbleY, 3, 0, Math.PI * 2);
        ctx.arc(obs.x + obs.width * 0.65, obs.y + 5, 2, 0, Math.PI * 2);
        ctx.fill();
      } else if (obs.type === 'candy_pop') {
        // Bouncy lavender & pink sugar spikes
        ctx.fillStyle = '#c084fc';
        const numSpikes = Math.floor(obs.width / 16);
        for (let i = 0; i < numSpikes; i++) {
          const sx = obs.x + i * 16;
          ctx.beginPath();
          ctx.moveTo(sx, obs.y + obs.height);
          ctx.lineTo(sx + 8, obs.y);
          ctx.lineTo(sx + 16, obs.y + obs.height);
          ctx.closePath();
          ctx.fill();
        }
      }
    }
  }

  // --- Checkpoints ---
  private renderCheckpoints(ctx: CanvasRenderingContext2D, level: LevelData) {
    for (const cp of level.checkpoints) {
      // Candy-striped flagpole (pink & white)
      ctx.fillStyle = '#f472b6';
      ctx.fillRect(cp.x, cp.y - 70, 5, 70);

      // Pennant flag with strawberry theme
      ctx.fillStyle = cp.reached ? '#f43f5e' : '#c084fc';
      const wave = Math.sin(this.animTimer * 4) * 4;
      ctx.beginPath();
      ctx.moveTo(cp.x + 5, cp.y - 70);
      ctx.lineTo(cp.x + 40 + wave, cp.y - 55);
      ctx.lineTo(cp.x + 5, cp.y - 40);
      ctx.closePath();
      ctx.fill();

      // Strawberry emblem on flag
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(cp.x + 18, cp.y - 55, 4, 0, Math.PI * 2);
      ctx.fill();

      // Strawberry seed dot
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(cp.x + 18, cp.y - 55, 1.5, 0, Math.PI * 2);
      ctx.fill();

      // Base pedestal (pink flower pot)
      ctx.fillStyle = '#db2777';
      ctx.beginPath();
      ctx.roundRect(cp.x - 8, cp.y - 6, 22, 8, 3);
      ctx.fill();
    }
  }

  // --- Question Shrines (Tugu Pengetahuan Stroberi) ---
  private renderQuestionTriggers(ctx: CanvasRenderingContext2D, level: LevelData) {
    for (const qt of level.questionTriggers) {
      const isCompleted = qt.triggered;
      const pulse = Math.sin(this.animTimer * 4 + qt.x) * 3;

      // Soft pink & lavender glowing aura
      if (!isCompleted) {
        ctx.fillStyle = 'rgba(244, 114, 182, 0.28)';
        ctx.beginPath();
        ctx.arc(qt.x + qt.width / 2, qt.y - 25, 34 + pulse, 0, Math.PI * 2);
        ctx.fill();
      }

      // Pastel Pedestal
      ctx.fillStyle = '#c084fc';
      ctx.fillRect(qt.x + 8, qt.y - 30, qt.width - 16, 30);
      ctx.fillStyle = '#7e22ce';
      ctx.fillRect(qt.x + 2, qt.y - 6, qt.width - 4, 8);

      // Floating Strawberry Jewel Tablet
      ctx.fillStyle = isCompleted ? '#22c55e' : '#f43f5e';
      ctx.beginPath();
      ctx.roundRect(qt.x + 4, qt.y - 62 + pulse, qt.width - 8, 32, 10);
      ctx.fill();

      // Strawberry calyx/leaf on top of tablet
      ctx.fillStyle = '#4ade80';
      ctx.beginPath();
      ctx.ellipse(qt.x + qt.width / 2, qt.y - 62 + pulse, 12, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Border
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Icon: ? or Checkmark
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 20px Fredoka, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(isCompleted ? '✓' : '?', qt.x + qt.width / 2, qt.y - 46 + pulse);

      // Indicator label
      if (!isCompleted) {
        ctx.fillStyle = '#581c87';
        ctx.font = 'bold 10px Nunito Sans, sans-serif';
        ctx.fillText('Tantangan Gizi', qt.x + qt.width / 2, qt.y - 74 + pulse);
      }
    }
  }

  // --- Coins ---
  private renderCoins(ctx: CanvasRenderingContext2D, level: LevelData) {
    for (const coin of level.coins) {
      if (coin.collected) continue;

      const bob = Math.sin(this.animTimer * 4 + coin.bobOffset) * 4;
      const spin = Math.cos(this.animTimer * 5 + coin.bobOffset);
      const cx = coin.x;
      const cy = coin.y + bob;

      // Glow behind coin
      ctx.fillStyle = 'rgba(253, 224, 71, 0.4)';
      ctx.beginPath();
      ctx.arc(cx, cy, 14, 0, Math.PI * 2);
      ctx.fill();

      // Golden berry coin ellipse (3D spin simulation)
      const rx = Math.max(2, Math.abs(spin) * 11);
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx, 11, 0, 0, Math.PI * 2);
      ctx.fill();

      // Inner coin rim & cute berry symbol
      if (rx > 5) {
        ctx.strokeStyle = '#ca8a04';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx - 3, 8, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = '#e11d48';
        ctx.beginPath();
        ctx.arc(cx, cy, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#4ade80';
        ctx.fillRect(cx - 1, cy - 4.5, 2, 2);
      }
    }
  }

  // --- NPCs (Sweet Berry Style) ---
  private renderNPCs(ctx: CanvasRenderingContext2D, level: LevelData, player: Player) {
    for (const npc of level.npcs) {
      const bob = Math.sin(this.animTimer * 2.5) * 2;
      const nx = npc.x;
      const ny = npc.y + bob;

      // Character body
      if (npc.avatar === 'pak_arif') {
        // Cute gardener with straw hat & strawberry leaf brooch
        ctx.fillStyle = '#93c5fd'; // Soft denim overalls
        ctx.beginPath();
        ctx.roundRect(nx - 14, ny - 45, 28, 42, 8);
        ctx.fill();

        // Head
        ctx.fillStyle = '#ffedd5';
        ctx.beginPath();
        ctx.arc(nx, ny - 55, 13, 0, Math.PI * 2);
        ctx.fill();

        // Straw hat with pink ribbon
        ctx.fillStyle = '#fde68a';
        ctx.beginPath();
        ctx.ellipse(nx, ny - 65, 20, 6, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(nx, ny - 68, 10, Math.PI, 0);
        ctx.fill();
        ctx.fillStyle = '#f43f5e';
        ctx.fillRect(nx - 10, ny - 67, 20, 3);
      } else if (npc.avatar === 'koki_ratna') {
        // Berry baker with pink cupcake toque and lavender apron
        ctx.fillStyle = '#fdf4ff';
        ctx.beginPath();
        ctx.roundRect(nx - 14, ny - 45, 28, 42, 8);
        ctx.fill();

        // Lavender apron
        ctx.fillStyle = '#c084fc';
        ctx.fillRect(nx - 10, ny - 40, 20, 32);

        // Head
        ctx.fillStyle = '#fed7aa';
        ctx.beginPath();
        ctx.arc(nx, ny - 55, 13, 0, Math.PI * 2);
        ctx.fill();

        // Pink cupcake toque
        ctx.fillStyle = '#fbcfe8';
        ctx.beginPath();
        ctx.roundRect(nx - 11, ny - 80, 22, 20, 6);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(nx, ny - 80, 13, 0, Math.PI * 2);
        ctx.fill();
        // Strawberry cherry on top
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(nx, ny - 93, 4, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Caring berry doctor with lilac lab coat and strawberry stethoscope
        ctx.fillStyle = '#f5d0fe'; // Lilac dress
        ctx.beginPath();
        ctx.roundRect(nx - 14, ny - 45, 28, 42, 8);
        ctx.fill();

        // White doctor coat
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(nx - 14, ny - 45, 7, 42);
        ctx.fillRect(nx + 7, ny - 45, 7, 42);

        // Head
        ctx.fillStyle = '#ffedd5';
        ctx.beginPath();
        ctx.arc(nx, ny - 55, 13, 0, Math.PI * 2);
        ctx.fill();

        // Stethoscope with strawberry bell
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(nx, ny - 42, 8, 0, Math.PI);
        ctx.stroke();
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(nx, ny - 34, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // Friendly interaction bubble when player is nearby
      const dist = Math.abs(player.x - nx);
      if (dist < 120) {
        const bubblePulse = Math.sin(this.animTimer * 5) * 2;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.roundRect(nx - 45, ny - 105 + bubblePulse, 90, 24, 8);
        ctx.fill();

        ctx.strokeStyle = '#f472b6';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#581c87';
        ctx.font = 'bold 11px Fredoka, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('[E] Bicara', nx, ny - 93 + bubblePulse);
      }
    }
  }

  // --- Level Exit (Whimsical Strawberry Cottage Archway) ---
  private renderExit(ctx: CanvasRenderingContext2D, level: LevelData) {
    const ex = level.exit.x;
    const ey = level.exit.y;
    const pulse = Math.sin(this.animTimer * 3) * 4;

    const totalQuestions = level.questionTriggers.length;
    const answeredQuestions = level.questionTriggers.filter((q) => q.triggered).length;
    const isUnlocked = answeredQuestions >= totalQuestions;

    // Glowing Berry Archway
    ctx.fillStyle = isUnlocked ? 'rgba(244, 114, 182, 0.4)' : 'rgba(192, 132, 252, 0.2)';
    ctx.beginPath();
    ctx.arc(ex + 30, ey + 40, 50 + pulse, 0, Math.PI * 2);
    ctx.fill();

    // Arch columns (Strawberry pink)
    ctx.fillStyle = isUnlocked ? '#f43f5e' : '#db2777';
    ctx.beginPath();
    ctx.roundRect(ex, ey + 10, 14, 70, 4);
    ctx.roundRect(ex + 46, ey + 10, 14, 70, 4);
    ctx.fill();

    // Strawberry top arch
    ctx.beginPath();
    ctx.arc(ex + 30, ey + 15, 30, Math.PI, 0);
    ctx.fillStyle = isUnlocked ? '#f43f5e' : '#c084fc';
    ctx.fill();

    // Calyx leaves on arch
    ctx.fillStyle = '#4ade80';
    ctx.beginPath();
    ctx.ellipse(ex + 30, ey - 8, 16, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Doorway opening
    if (isUnlocked) {
      const doorGrad = ctx.createLinearGradient(0, ey + 15, 0, ey + 80);
      doorGrad.addColorStop(0, '#fef08a');
      doorGrad.addColorStop(1, '#ffffff');
      ctx.fillStyle = doorGrad;
      ctx.fillRect(ex + 14, ey + 20, 32, 60);
    } else {
      // Locked wooden door with candy bars
      ctx.fillStyle = '#7e22ce';
      ctx.fillRect(ex + 14, ey + 20, 32, 60);

      ctx.strokeStyle = '#c084fc';
      ctx.lineWidth = 2;
      for (let bx = ex + 20; bx <= ex + 40; bx += 8) {
        ctx.beginPath();
        ctx.moveTo(bx, ey + 20);
        ctx.lineTo(bx, ey + 80);
        ctx.stroke();
      }
    }

    // Signboard banner
    ctx.fillStyle = isUnlocked ? '#be185d' : '#581c87';
    ctx.beginPath();
    ctx.roundRect(ex - 10, ey - 8, 80, 20, 6);
    ctx.fill();

    ctx.font = 'bold 9px Fredoka, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(
      isUnlocked ? 'GERBANG BUKA ▶' : `KUNCI (${answeredQuestions}/${totalQuestions})`,
      ex + 30,
      ey + 2
    );
  }

  // --- Protagonist (Strawberry Shortcake inspired adorable cartoon hero) ---
  private renderPlayer(ctx: CanvasRenderingContext2D, player: Player) {
    // If invulnerable, flicker
    if (player.invulnerableTime > 0 && Math.floor(player.invulnerableTime * 20) % 2 === 0) {
      return;
    }

    ctx.save();
    ctx.translate(player.x + player.width / 2, player.y + player.height / 2);

    if (player.facingLeft) {
      ctx.scale(-1, 1);
    }

    const t = this.animTimer;
    let legOffset = 0;
    let armOffset = 0;
    let bodyBob = 0;

    if (player.state === 'running') {
      legOffset = Math.sin(t * 14) * 11;
      armOffset = Math.cos(t * 14) * 9;
      bodyBob = Math.abs(Math.sin(t * 14)) * 3.5;
    } else if (player.state === 'jumping' || player.state === 'falling') {
      legOffset = -6;
      armOffset = 14;
      bodyBob = -2;
    } else {
      // Idle breathing
      bodyBob = Math.sin(t * 3) * 1.5;
    }

    // 1. Cute Strawberry Backpack / Pouch (Behind)
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.roundRect(-18, -14 - bodyBob, 10, 16, 5);
    ctx.fill();
    ctx.fillStyle = '#4ade80';
    ctx.beginPath();
    ctx.ellipse(-13, -14 - bodyBob, 5, 2.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. Legs with Iconic Green-and-White Striped Stockings!
    const legY = 6 - bodyBob;
    // Left Leg
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-8, legY, 6, 13 + legOffset * 0.4);
    ctx.fillStyle = '#4ade80';
    ctx.fillRect(-8, legY + 3, 6, 3);
    ctx.fillRect(-8, legY + 8, 6, 3);

    // Right Leg
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(2, legY, 6, 13 - legOffset * 0.4);
    ctx.fillStyle = '#4ade80';
    ctx.fillRect(2, legY + 3, 6, 3);
    ctx.fillRect(2, legY + 8, 6, 3);

    // Sweet Strawberry Mary Jane Shoes
    ctx.fillStyle = '#e11d48';
    ctx.beginPath();
    ctx.roundRect(-10, 18 - bodyBob + legOffset * 0.4, 9, 6, 3);
    ctx.roundRect(1, 18 - bodyBob - legOffset * 0.4, 9, 6, 3);
    ctx.fill();

    // 3. Dress (Sweet Pastel Pink & Lavender Pinafore)
    ctx.fillStyle = '#f472b6'; // Pastel pink dress
    ctx.beginPath();
    ctx.moveTo(-11, -12 - bodyBob);
    ctx.lineTo(11, -12 - bodyBob);
    ctx.lineTo(13, 8 - bodyBob);
    ctx.lineTo(-13, 8 - bodyBob);
    ctx.closePath();
    ctx.fill();

    // White ruffled pinafore apron
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.roundRect(-7, -10 - bodyBob, 14, 14, 3);
    ctx.fill();

    // Tiny strawberry emblem on apron
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(0, -3 - bodyBob, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#4ade80';
    ctx.fillRect(-1, -6 - bodyBob, 2, 2);

    // 4. Arms & Puffy Sleeves
    ctx.fillStyle = '#fbcfe8';
    if (player.state === 'winning') {
      // Victory hands up
      ctx.fillRect(-12, -26, 5, 14);
      ctx.fillRect(7, -26, 5, 14);
    } else {
      ctx.save();
      ctx.translate(4, -6 - bodyBob);
      ctx.rotate((armOffset * Math.PI) / 180);
      ctx.fillRect(-2, 0, 5, 14);
      ctx.restore();
    }

    // 5. Head, Sweet Pastel Hair Curls, & Cute Cartoon Face
    const headY = -23 - bodyBob;

    // Pastel strawberry curls (Back hair)
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.arc(-8, headY + 2, 7, 0, Math.PI * 2);
    ctx.arc(-10, headY + 8, 6, 0, Math.PI * 2);
    ctx.arc(8, headY + 2, 7, 0, Math.PI * 2);
    ctx.fill();

    // Face skin
    ctx.fillStyle = '#ffedd5';
    ctx.beginPath();
    ctx.arc(0, headY, 11, 0, Math.PI * 2);
    ctx.fill();

    // Rosy blushing strawberry cheeks
    ctx.fillStyle = 'rgba(244, 63, 94, 0.4)';
    ctx.beginPath();
    ctx.arc(-5, headY + 3, 3, 0, Math.PI * 2);
    ctx.arc(5, headY + 3, 3, 0, Math.PI * 2);
    ctx.fill();

    // Cartoon anime eyes with sparkle catchlights
    ctx.fillStyle = '#581c87'; // Deep purple eye
    ctx.beginPath();
    ctx.arc(4, headY - 1, 2.5, 0, Math.PI * 2);
    ctx.fill();
    // White eye catchlight
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(4.8, headY - 1.8, 1, 0, Math.PI * 2);
    ctx.fill();

    // Sweet smile
    ctx.strokeStyle = '#be185d';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(3, headY + 4, 2.5, 0, Math.PI);
    ctx.stroke();

    // Front hair bangs / curls
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.arc(-4, headY - 8, 5, 0, Math.PI * 2);
    ctx.arc(3, headY - 8, 6, 0, Math.PI * 2);
    ctx.fill();

    // 6. Iconic Strawberry Beret Hat!
    // Floppy strawberry dome
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(0, headY - 6, 15, Math.PI * 0.9, Math.PI * 0.1);
    ctx.closePath();
    ctx.fill();

    // Hat brim
    ctx.fillStyle = '#e11d48';
    ctx.beginPath();
    ctx.ellipse(0, headY - 6, 17, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Yellow strawberry seeds on hat
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(-7, headY - 12, 1, 0, Math.PI * 2);
    ctx.arc(0, headY - 14, 1, 0, Math.PI * 2);
    ctx.arc(7, headY - 12, 1, 0, Math.PI * 2);
    ctx.arc(-3, headY - 8, 1, 0, Math.PI * 2);
    ctx.arc(4, headY - 8, 1, 0, Math.PI * 2);
    ctx.fill();

    // Green leafy strawberry calyx / crown
    ctx.fillStyle = '#4ade80';
    ctx.beginPath();
    ctx.ellipse(0, headY - 18, 8, 3, 0, 0, Math.PI * 2);
    ctx.fill();

    // Green stem
    ctx.fillStyle = '#16a34a';
    ctx.beginPath();
    ctx.roundRect(-1.5, headY - 24, 3, 7, 1);
    ctx.fill();

    ctx.restore();
  }

  // --- Particles ---
  private renderParticles(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.alpha;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
}
