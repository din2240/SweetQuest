// Game types and data contracts for GULIGO! FOOD ADVENTURE

export type GameScreen =
  | 'MAIN_MENU'
  | 'HOW_TO_PLAY'
  | 'SETTINGS'
  | 'CREDITS'
  | 'LEVEL_SELECT'
  | 'PLAYING'
  | 'PAUSED'
  | 'QUESTION_ACTIVE'
  | 'FEEDBACK'
  | 'NPC_DIALOGUE'
  | 'LEVEL_CLEAR'
  | 'FINAL_RESULTS'
  | 'TEACHER_DASHBOARD';

export type QuestionTopic =
  | 'MENGENAL_MINUMAN_MANIS'
  | 'MENGENAL_MAKANAN_MANIS'
  | 'MEMBACA_INFORMASI_GIZI'
  | 'GULA_DAN_TUBUHKU'
  | 'PILIHAN_MAKANAN_BIJAK';

export type QuestionDifficulty = 'Mudah' | 'Sedang' | 'Tantangan';

export interface NutritionLabelItem {
  name: string;
  servingSize: string;
  sugarGrams: number;
  highlightNote?: string;
  category: 'minuman' | 'makanan';
}

export interface QuestionData {
  id: string;
  topic: QuestionTopic;
  topicLabel: string;
  difficulty: QuestionDifficulty;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  nutritionComparison?: {
    itemA: NutritionLabelItem;
    itemB: NutritionLabelItem;
  };
}

export interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  facingLeft: boolean;
  isGrounded: boolean;
  isJumping: boolean;
  state: 'idle' | 'running' | 'jumping' | 'falling' | 'hurt' | 'winning';
  stateTime: number;
  invulnerableTime: number;
  lives: number;
  maxLives: number;
  score: number;
  coins: number;
}

export interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'ground' | 'wood' | 'leaf' | 'stone' | 'crystal' | 'moving';
  moveRange?: number;
  moveSpeed?: number;
  initialX?: number;
}

export interface Coin {
  id: string;
  x: number;
  y: number;
  collected: boolean;
  bobOffset: number;
}

export interface Obstacle {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'spikes' | 'mud' | 'syrup' | 'boulder' | 'candy_pop';
  moveSpeed?: number;
  moveRange?: number;
  initialX?: number;
}

export interface Checkpoint {
  id: string;
  x: number;
  y: number;
  reached: boolean;
  name: string;
}

export interface QuestionTrigger {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  questionId: string;
  triggered: boolean;
  answeredCorrectly?: boolean;
}

export interface NPC {
  id: string;
  name: string;
  title: string;
  avatar: 'pak_arif' | 'koki_ratna' | 'dokter_gita';
  x: number;
  y: number;
  dialogue: string[];
}

export interface LevelExit {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface LevelData {
  id: number;
  name: string;
  title: string;
  subtitle: string;
  learningFocus: string;
  worldWidth: number;
  worldHeight: number;
  theme: 'valley' | 'forest' | 'castle';
  skyColors: [string, string];
  groundColor: string;
  platforms: Platform[];
  coins: Coin[];
  obstacles: Obstacle[];
  checkpoints: Checkpoint[];
  questionTriggers: QuestionTrigger[];
  npcs: NPC[];
  exit: LevelExit;
}

export interface PlayerAnswerRecord {
  questionId: string;
  topic: QuestionTopic;
  topicLabel: string;
  question: string;
  chosenIndex: number;
  correctIndex: number;
  isCorrect: boolean;
  timestamp: number;
}

export interface GameSessionResult {
  id: string;
  studentCode: string;
  date: string;
  timestamp: number;
  totalScore: number;
  totalCoins: number;
  correctCount: number;
  incorrectCount: number;
  completedLevels: number;
  accuracyPercent: number;
  answers: PlayerAnswerRecord[];
}

export interface AudioSettings {
  bgmEnabled: boolean;
  sfxEnabled: boolean;
  bgmVolume: number;
  sfxVolume: number;
}

export interface SavedProgress {
  unlockedLevel: number;
  currentLevel: number;
  highScore: number;
  totalCoins: number;
  sessionsCompleted: number;
  audioSettings: AudioSettings;
}
