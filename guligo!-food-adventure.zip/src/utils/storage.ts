// Local Storage management and Teacher Dashboard analytics for GULIGO! FOOD ADVENTURE

import { GameSessionResult, SavedProgress, PlayerAnswerRecord } from '../types/game';

const PROGRESS_KEY = 'guligo_player_progress';
const SESSIONS_KEY = 'guligo_teacher_sessions';

export function getSavedProgress(): SavedProgress {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {
    // Fallback
  }
  return {
    unlockedLevel: 1,
    currentLevel: 1,
    highScore: 0,
    totalCoins: 0,
    sessionsCompleted: 0,
    audioSettings: {
      bgmEnabled: true,
      sfxEnabled: true,
      bgmVolume: 0.6,
      sfxVolume: 0.8,
    },
  };
}

export function saveProgress(updates: Partial<SavedProgress>): SavedProgress {
  const current = getSavedProgress();
  const merged: SavedProgress = {
    ...current,
    ...updates,
    unlockedLevel: Math.max(current.unlockedLevel, updates.unlockedLevel ?? 1),
    highScore: Math.max(current.highScore, updates.highScore ?? 0),
  };
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(merged));
  } catch {
    // Fallback
  }
  return merged;
}

export function getAllSessions(): GameSessionResult[] {
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {
    // Fallback
  }
  // Provide sample sessions if empty so teacher dashboard isn't completely blank on first inspection
  const initialData: GameSessionResult[] = [
    {
      id: 'SESI-01',
      studentCode: 'Penjelajah #1',
      date: '06/11/2026 09:15',
      timestamp: Date.now() - 86400000,
      totalScore: 1450,
      totalCoins: 28,
      correctCount: 13,
      incorrectCount: 2,
      completedLevels: 3,
      accuracyPercent: 87,
      answers: []
    },
    {
      id: 'SESI-02',
      studentCode: 'Penjelajah #2',
      date: '06/11/2026 10:30',
      timestamp: Date.now() - 43200000,
      totalScore: 1620,
      totalCoins: 35,
      correctCount: 14,
      incorrectCount: 1,
      completedLevels: 3,
      accuracyPercent: 93,
      answers: []
    }
  ];
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(initialData));
  } catch {
    // Fallback
  }
  return initialData;
}

export function saveGameSession(
  score: number,
  coins: number,
  answers: PlayerAnswerRecord[],
  completedLevels: number
): GameSessionResult {
  const sessions = getAllSessions();
  const nextNum = sessions.length + 1;
  const correctCount = answers.filter((a) => a.isCorrect).length;
  const incorrectCount = answers.length - correctCount;
  const accuracyPercent = answers.length > 0 ? Math.round((correctCount / answers.length) * 100) : 100;

  const now = new Date();
  const dateFormatted = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const newSession: GameSessionResult = {
    id: `SESI-${String(nextNum).padStart(2, '0')}`,
    studentCode: `Penjelajah #${nextNum}`,
    date: dateFormatted,
    timestamp: Date.now(),
    totalScore: score,
    totalCoins: coins,
    correctCount,
    incorrectCount,
    completedLevels,
    accuracyPercent,
    answers,
  };

  const updated = [newSession, ...sessions];
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(updated));
  } catch {
    // Fallback
  }

  // Update progress stats
  saveProgress({
    sessionsCompleted: getSavedProgress().sessionsCompleted + 1,
    totalCoins: getSavedProgress().totalCoins + coins,
    highScore: score,
  });

  return newSession;
}

export function resetAllData(): void {
  try {
    localStorage.removeItem(PROGRESS_KEY);
    localStorage.removeItem(SESSIONS_KEY);
  } catch {
    // Fallback
  }
}

// Export teacher records to CSV with Indonesian headers
export function exportSessionsToCSV(sessions: GameSessionResult[]): void {
  const headers = [
    'Kode_Siswa',
    'Tanggal_Waktu',
    'Total_Nilai',
    'Total_Koin',
    'Jawaban_Benar',
    'Jawaban_Belum_Tepat',
    'Akurasi_Persen',
    'Level_Terselesaikan'
  ];

  const rows = sessions.map((s) => [
    `"${s.studentCode}"`,
    `"${s.date}"`,
    s.totalScore,
    s.totalCoins,
    s.correctCount,
    s.incorrectCount,
    `${s.accuracyPercent}%`,
    s.completedLevels
  ]);

  const csvContent = [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `guligo_data_hasil_belajar_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
