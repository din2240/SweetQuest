// Web Audio API pure synthesizer for GULIGO! FOOD ADVENTURE
// Zero external file dependencies - always works in hermetic environments!

import { AudioSettings } from '../types/game';

class SoundController {
  private ctx: AudioContext | null = null;
  private bgmGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private bgmIntervalId: number | null = null;
  private currentBgmLevel: number | null = null;

  public settings: AudioSettings = {
    bgmEnabled: true,
    sfxEnabled: true,
    bgmVolume: 0.6,
    sfxVolume: 0.8,
  };

  constructor() {
    this.loadSettings();
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    if (!this.bgmGainNode && this.ctx) {
      this.bgmGainNode = this.ctx.createGain();
      this.bgmGainNode.connect(this.ctx.destination);
      this.updateBgmGain();
    }
    if (!this.sfxGainNode && this.ctx) {
      this.sfxGainNode = this.ctx.createGain();
      this.sfxGainNode.connect(this.ctx.destination);
      this.updateSfxGain();
    }
  }

  private loadSettings() {
    try {
      const saved = localStorage.getItem('guligo_audio_settings');
      if (saved) {
        this.settings = { ...this.settings, ...JSON.parse(saved) };
      }
    } catch {
      // Ignore fallback
    }
  }

  public saveSettings(newSettings: Partial<AudioSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    this.updateBgmGain();
    this.updateSfxGain();
    try {
      localStorage.setItem('guligo_audio_settings', JSON.stringify(this.settings));
    } catch {
      // Ignore
    }
  }

  private updateBgmGain() {
    if (this.bgmGainNode && this.ctx) {
      const targetGain = this.settings.bgmEnabled ? this.settings.bgmVolume * 0.15 : 0;
      this.bgmGainNode.gain.setValueAtTime(targetGain, this.ctx.currentTime);
    }
  }

  private updateSfxGain() {
    if (this.sfxGainNode && this.ctx) {
      const targetGain = this.settings.sfxEnabled ? this.settings.sfxVolume * 0.35 : 0;
      this.sfxGainNode.gain.setValueAtTime(targetGain, this.ctx.currentTime);
    }
  }

  // --- Sound Effects ---
  public playSFX(
    type: 'jump' | 'coin' | 'correct' | 'incorrect' | 'checkpoint' | 'hurt' | 'click' | 'level_clear' | 'dialogue'
  ) {
    if (!this.settings.sfxEnabled) return;
    try {
      this.initCtx();
      if (!this.ctx || !this.sfxGainNode) return;

      const t = this.ctx.currentTime;

      if (type === 'jump') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(180, t);
        osc.frequency.exponentialRampToValueAtTime(460, t + 0.16);
        gain.gain.setValueAtTime(0.5, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.16);
        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.16);
      } else if (type === 'coin') {
        const freqs = [880, 1318];
        freqs.forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, t + idx * 0.06);
          gain.gain.setValueAtTime(0.4, t + idx * 0.06);
          gain.gain.exponentialRampToValueAtTime(0.01, t + idx * 0.06 + 0.15);
          osc.connect(gain);
          gain.connect(this.sfxGainNode!);
          osc.start(t + idx * 0.06);
          osc.stop(t + idx * 0.06 + 0.15);
        });
      } else if (type === 'correct') {
        // Triumphal major arpeggio: C5 (523), E5 (659), G5 (784), C6 (1046)
        const notes = [523.25, 659.25, 783.99, 1046.5];
        notes.forEach((freq, i) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, t + i * 0.08);
          gain.gain.setValueAtTime(0.5, t + i * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.01, t + i * 0.08 + 0.3);
          osc.connect(gain);
          gain.connect(this.sfxGainNode!);
          osc.start(t + i * 0.08);
          osc.stop(t + i * 0.08 + 0.3);
        });
      } else if (type === 'incorrect') {
        // Encouraging gentle bell tone: E4 (329), G4 (392)
        const notes = [392, 329.63];
        notes.forEach((freq, i) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, t + i * 0.14);
          gain.gain.setValueAtTime(0.35, t + i * 0.14);
          gain.gain.exponentialRampToValueAtTime(0.01, t + i * 0.14 + 0.35);
          osc.connect(gain);
          gain.connect(this.sfxGainNode!);
          osc.start(t + i * 0.14);
          osc.stop(t + i * 0.14 + 0.35);
        });
      } else if (type === 'checkpoint') {
        // Brass chime
        const notes = [440, 554.37, 659.25, 880];
        notes.forEach((freq, i) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, t + i * 0.07);
          gain.gain.setValueAtTime(0.45, t + i * 0.07);
          gain.gain.exponentialRampToValueAtTime(0.01, t + i * 0.07 + 0.35);
          osc.connect(gain);
          gain.connect(this.sfxGainNode!);
          osc.start(t + i * 0.07);
          osc.stop(t + i * 0.07 + 0.35);
        });
      } else if (type === 'hurt') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(220, t);
        osc.frequency.exponentialRampToValueAtTime(100, t + 0.2);
        gain.gain.setValueAtTime(0.5, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);
        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.2);
      } else if (type === 'click') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, t);
        osc.frequency.exponentialRampToValueAtTime(200, t + 0.04);
        gain.gain.setValueAtTime(0.3, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.04);
        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.04);
      } else if (type === 'level_clear') {
        const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];
        notes.forEach((freq, i) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, t + i * 0.1);
          gain.gain.setValueAtTime(0.5, t + i * 0.1);
          gain.gain.exponentialRampToValueAtTime(0.01, t + i * 0.1 + 0.5);
          osc.connect(gain);
          gain.connect(this.sfxGainNode!);
          osc.start(t + i * 0.1);
          osc.stop(t + i * 0.1 + 0.5);
        });
      } else if (type === 'dialogue') {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440 + Math.random() * 80, t);
        gain.gain.setValueAtTime(0.15, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.05);
        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.05);
      }
    } catch {
      // Audio error safety
    }
  }

  // --- Background Music ---
  public playBGM(levelNum: number = 1) {
    if (this.currentBgmLevel === levelNum && this.bgmIntervalId !== null) return;
    this.stopBGM();
    this.currentBgmLevel = levelNum;

    try {
      this.initCtx();
      if (!this.ctx || !this.bgmGainNode) return;

      // Adventure melody loops (pentatonic uplifting tune)
      // Level 1: C major / G major happy bouncy marimba style
      // Level 2: F major / D minor mystical sweet forest
      // Level 3: G major grand regal castle
      const melodies: Record<number, number[]> = {
        0: [261.63, 329.63, 392.00, 523.25, 392.00, 329.63, 440.00, 392.00], // Menu
        1: [392.00, 440.00, 523.25, 659.25, 783.99, 659.25, 523.25, 440.00, 392.00, 523.25, 440.00, 329.63], // Lembah
        2: [349.23, 440.00, 523.25, 587.33, 698.46, 587.33, 523.25, 440.00, 392.00, 440.00, 523.25, 349.23], // Hutan
        3: [392.00, 493.88, 587.33, 783.99, 880.00, 783.99, 587.33, 493.88, 587.33, 659.25, 587.33, 392.00], // Istana
      };

      const notes = melodies[levelNum] || melodies[1];
      let step = 0;
      const tempoMs = 260; // Upbeat pleasant tempo

      const playNote = () => {
        if (!this.ctx || !this.bgmGainNode || !this.settings.bgmEnabled) return;
        const now = this.ctx.currentTime;
        const freq = notes[step % notes.length];
        step++;

        // Lead synth note (soft marimba)
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = levelNum === 3 ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        // Low-pass filter for warm sound
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(levelNum === 3 ? 1200 : 900, now);

        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.24);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.bgmGainNode);
        osc.start(now);
        osc.stop(now + 0.25);

        // Gentle walking bass note every 2 steps
        if (step % 2 === 0) {
          const bassOsc = this.ctx.createOscillator();
          const bassGain = this.ctx.createGain();
          bassOsc.type = 'triangle';
          bassOsc.frequency.setValueAtTime(freq / 2, now);
          bassGain.gain.setValueAtTime(0.14, now);
          bassGain.gain.exponentialRampToValueAtTime(0.005, now + 0.45);
          bassOsc.connect(bassGain);
          bassGain.connect(this.bgmGainNode);
          bassOsc.start(now);
          bassOsc.stop(now + 0.46);
        }
      };

      this.bgmIntervalId = window.setInterval(playNote, tempoMs);
      playNote();
    } catch {
      // Audio error safety
    }
  }

  public stopBGM() {
    if (this.bgmIntervalId !== null) {
      clearInterval(this.bgmIntervalId);
      this.bgmIntervalId = null;
    }
    this.currentBgmLevel = null;
  }
}

export const soundManager = new SoundController();
