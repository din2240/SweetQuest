// Bank Soal Edukatif GULIGO! FOOD ADVENTURE
// Dikhususkan untuk siswa SD kelas 4-6 (usia 9-12 tahun)
// Menggunakan Bahasa Indonesia yang alami, jelas, dan santun (sesuai PUEBI)

import { QuestionData, QuestionTopic } from '../types/game';

export const TOPIC_NAMES: Record<QuestionTopic, string> = {
  MENGENAL_MINUMAN_MANIS: 'Mengenal Minuman Manis',
  MENGENAL_MAKANAN_MANIS: 'Mengenal Makanan Manis',
  MEMBACA_INFORMASI_GIZI: 'Membaca Informasi Gizi',
  GULA_DAN_TUBUHKU: 'Gula dan Tubuhku',
  PILIHAN_MAKANAN_BIJAK: 'Pilihan Makanan yang Bijak',
};

export const QUESTION_BANK: QuestionData[] = [
  // --- 1. MENGENAL MINUMAN MANIS (Fokus Utama Level 1) ---
  {
    id: 'MM-01',
    topic: 'MENGENAL_MINUMAN_MANIS',
    topicLabel: 'Mengenal Minuman Manis',
    difficulty: 'Mudah',
    question: 'Setelah bermain di lapangan, kamu merasa haus. Minuman apa yang paling baik untuk menghilangkan dahaga?',
    options: [
      'Air putih.',
      'Soda.',
      'Teh manis kemasan.',
      'Minuman rasa buah dalam kemasan.'
    ],
    correctIndex: 0,
    explanation: 'Air putih membantu menggantikan cairan tubuh dengan cepat dan tidak mengandung gula tambahan sama sekali.'
  },
  {
    id: 'MM-02',
    topic: 'MENGENAL_MINUMAN_MANIS',
    topicLabel: 'Mengenal Minuman Manis',
    difficulty: 'Mudah',
    question: 'Manakah minuman berikut yang biasanya memiliki tambahan gula?',
    options: [
      'Air putih.',
      'Teh tawar dingin.',
      'Minuman bersoda.',
      'Air mineral pegunungan.'
    ],
    correctIndex: 2,
    explanation: 'Minuman bersoda umumnya mengandung gula tambahan dalam jumlah cukup tinggi, sehingga sebaiknya tidak diminum terlalu sering.'
  },
  {
    id: 'MM-03',
    topic: 'MENGENAL_MINUMAN_MANIS',
    topicLabel: 'Mengenal Minuman Manis',
    difficulty: 'Sedang',
    question: 'Kamu ingin membeli minuman di kantin. Ada dua pilihan: air putih dan teh manis kemasan. Jika diminum setiap hari, pilihan mana yang lebih baik?',
    options: [
      'Teh manis karena rasanya lebih enak.',
      'Air putih karena tidak mengandung gula tambahan.',
      'Keduanya sama saja untuk tubuh.',
      'Teh manis karena warnanya lebih menarik.'
    ],
    correctIndex: 1,
    explanation: 'Air putih adalah pilihan terbaik untuk minuman sehari-hari karena menjaga hidrasi tubuh tanpa menambah beban gula berlebih.'
  },
  {
    id: 'MM-04',
    topic: 'MENGENAL_MINUMAN_MANIS',
    topicLabel: 'Mengenal Minuman Manis',
    difficulty: 'Sedang',
    question: 'Minuman boba atau teh susu manis yang sedang populer biasanya mengandung...',
    options: [
      'Hanya air dan es batu biasa.',
      'Gula tambahan dan sirup pemanis dalam jumlah cukup banyak.',
      'Hanya vitamin tanpa pemanis tambahan.',
      'Zat gizi lengkap pengganti makan siang.'
    ],
    correctIndex: 1,
    explanation: 'Minuman kekinian seperti boba dan teh susu umumnya menggunakan sirup dan gula tambahan yang cukup tinggi. Boleh dinikmati sesekali saja, bukan setiap hari.'
  },
  {
    id: 'MM-05',
    topic: 'MENGENAL_MINUMAN_MANIS',
    topicLabel: 'Mengenal Minuman Manis',
    difficulty: 'Tantangan',
    question: 'Berapa banyak gelas air putih yang dianjurkan untuk diminum anak-anak setiap hari agar tubuh tetap segar?',
    options: [
      '1 hingga 2 gelas saja.',
      'Sekitar 6 sampai 8 gelas air putih.',
      'Hanya minum jika tenggorokan terasa sakit.',
      '15 gelas air sekaligus dalam satu waktu.'
    ],
    correctIndex: 1,
    explanation: 'Anak-anak disarankan minum sekitar 6–8 gelas (sekitar 1,5 hingga 2 liter) air putih setiap hari untuk membantu konsentrasi belajar dan menjaga kebugaran.'
  },

  // --- 2. MENGENAL MAKANAN MANIS (Fokus Utama Level 2) ---
  {
    id: 'MK-01',
    topic: 'MENGENAL_MAKANAN_MANIS',
    topicLabel: 'Mengenal Makanan Manis',
    difficulty: 'Mudah',
    question: 'Manakah makanan berikut yang biasanya mengandung banyak gula tambahan?',
    options: [
      'Telur rebus.',
      'Kue donat dengan lapisan gula.',
      'Jagung rebus manis alami.',
      'Sayur bayam segar.'
    ],
    correctIndex: 1,
    explanation: 'Donat dengan lapisan gula (glaze) atau taburan meses mengandung banyak gula tambahan dari tepung manis dan lapisan pemanisnya.'
  },
  {
    id: 'MK-02',
    topic: 'MENGENAL_MAKANAN_MANIS',
    topicLabel: 'Mengenal Makanan Manis',
    difficulty: 'Sedang',
    question: 'Kamu ingin makan camilan setelah pulang sekolah. Pilihan mana yang paling baik menjadi camilan sehari-hari?',
    options: [
      'Buah potong segar seperti pepaya atau apel.',
      'Permen manis rasa karamel.',
      'Cokelat batangan berlapis gula tebal.',
      'Kue bolu dengan banyak krim mentega.'
    ],
    correctIndex: 0,
    explanation: 'Buah potong mengandung rasa manis alami sekaligus kaya akan serat, vitamin, dan air yang sangat baik bagi pencernaan dan daya tahan tubuh.'
  },
  {
    id: 'MK-03',
    topic: 'MENGENAL_MAKANAN_MANIS',
    topicLabel: 'Mengenal Makanan Manis',
    difficulty: 'Sedang',
    question: 'Apakah semua makanan yang rasanya manis harus dihindari sama sekali?',
    options: [
      'Ya, semua makanan manis berbahaya bagi anak.',
      'Ya, karena gula tidak boleh masuk ke dalam tubuh kita.',
      'Tidak, makanan manis boleh dinikmati dengan memperhatikan jumlah dan frekuensinya.',
      'Tidak, makanan manis bebas dimakan sebanyak mungkin.'
    ],
    correctIndex: 2,
    explanation: 'Kita tidak harus memusuhi semua makanan manis. Kuncinya adalah bijak: perhatikan porsinya dan jangan mengonsumsinya secara berlebihan setiap hari.'
  },
  {
    id: 'MK-04',
    topic: 'MENGENAL_MAKANAN_MANIS',
    topicLabel: 'Mengenal Makanan Manis',
    difficulty: 'Mudah',
    question: 'Rasa manis pada buah segar seperti pisang dan semangka berasal dari...',
    options: [
      'Pewarna makanan buatan.',
      'Gula alami yang menyatu dengan serat dan vitamin buah.',
      'Sirup gula yang disuntikkan ke dalam buah.',
      'Bahan pengawet buatan pabrik.'
    ],
    correctIndex: 1,
    explanation: 'Buah memiliki rasa manis alami. Karena kaya serat, gula alami dalam buah diserap tubuh secara perlahan dan lebih sehat dibandingkan gula tambahan.'
  },
  {
    id: 'MK-05',
    topic: 'MENGENAL_MAKANAN_MANIS',
    topicLabel: 'Mengenal Makanan Manis',
    difficulty: 'Tantangan',
    question: 'Manakah camilan tradisional berikut yang biasanya dibuat tanpa lapisan gula pasir berlebih?',
    options: [
      'Ubi kukus atau singkong rebus.',
      'Gula-gula kapas warna-warni.',
      'Lolipop manis aneka rasa.',
      'Kue sus berlapis cokelat cair pekat.'
    ],
    correctIndex: 0,
    explanation: 'Ubi kukus atau singkong rebus memberikan energi alami dari karbohidrat kompleks tanpa perlu tambahan gula pasir buatan.'
  },

  // --- 3. MEMBACA INFORMASI GIZI (Fokus Utama Level 2) ---
  {
    id: 'IG-01',
    topic: 'MEMBACA_INFORMASI_GIZI',
    topicLabel: 'Membaca Informasi Gizi',
    difficulty: 'Mudah',
    question: 'Perhatikan dua label minuman kemasan berikut. Minuman mana yang memiliki kandungan gula lebih sedikit?',
    options: [
      'Minuman A (8 gram gula).',
      'Minuman B (18 gram gula).',
      'Keduanya sama banyak.',
      'Tidak bisa diketahui dari label.'
    ],
    correctIndex: 0,
    explanation: 'Minuman A mengandung 8 gram gula, sedangkan Minuman B mengandung 18 gram gula. Maka Minuman A memiliki gula yang lebih sedikit.',
    nutritionComparison: {
      itemA: {
        name: 'Minuman Sari Lemon A',
        servingSize: '1 botol (250 ml)',
        sugarGrams: 8,
        highlightNote: 'Gula: 8 gram',
        category: 'minuman'
      },
      itemB: {
        name: 'Minuman Soda Manis B',
        servingSize: '1 kaleng (250 ml)',
        sugarGrams: 18,
        highlightNote: 'Gula: 18 gram (Tinggi)',
        category: 'minuman'
      }
    }
  },
  {
    id: 'IG-02',
    topic: 'MEMBACA_INFORMASI_GIZI',
    topicLabel: 'Membaca Informasi Gizi',
    difficulty: 'Mudah',
    question: 'Apa yang sebaiknya kamu perhatikan saat membaca label informasi nilai gizi pada kemasan minuman?',
    options: [
      'Warna dan kemilau kemasan.',
      'Gambar tokoh kartun pada kemasan.',
      'Jumlah gram gula pada tabel informasi gizi.',
      'Bentuk dan ukuran tutup botol.'
    ],
    correctIndex: 2,
    explanation: 'Tabel informasi nilai gizi mencantumkan jumlah gram gula dan zat gizi lain sehingga kita tahu persis apa yang masuk ke dalam tubuh kita.'
  },
  {
    id: 'IG-03',
    topic: 'MEMBACA_INFORMASI_GIZI',
    topicLabel: 'Membaca Informasi Gizi',
    difficulty: 'Sedang',
    question: 'Kamu menemukan dua minuman dengan rasa yang sama, tetapi kandungan gulanya berbeda. Apa tindakan yang paling bijak?',
    options: [
      'Memilih yang kemasannya paling besar warnanya.',
      'Memilih yang kandungan gulanya lebih sedikit.',
      'Memilih yang gambarnya paling ramai.',
      'Memilih yang harganya paling mahal saja.'
    ],
    correctIndex: 1,
    explanation: 'Membandingkan jumlah gula pada label membantu kita memilih produk yang lebih rendah gula untuk kesehatan jangka panjang.'
  },
  {
    id: 'IG-04',
    topic: 'MEMBACA_INFORMASI_GIZI',
    topicLabel: 'Membaca Informasi Gizi',
    difficulty: 'Tantangan',
    question: 'Perhatikan camilan biskuit berikut: Biskuit Gandum (4 gram gula) dan Wafer Krim Cokelat (16 gram gula). Apa kesimpulan yang tepat?',
    options: [
      'Wafer Krim mengandung gula 4 kali lipat lebih banyak daripada Biskuit Gandum.',
      'Biskuit Gandum lebih manis daripada Wafer Krim.',
      'Keduanya memiliki jumlah gula yang identik.',
      'Jumlah gula tidak memengaruhi pilihan camilan kita.'
    ],
    correctIndex: 0,
    explanation: '16 gram adalah 4 kali dari 4 gram. Mengetahui angka ini membuat kita sadar bahwa wafer krim mengandung gula yang jauh lebih pekat.',
    nutritionComparison: {
      itemA: {
        name: 'Biskuit Gandum Utuh',
        servingSize: '3 keping (30 g)',
        sugarGrams: 4,
        highlightNote: 'Gula: 4 gram (Rendah)',
        category: 'makanan'
      },
      itemB: {
        name: 'Wafer Krim Cokelat',
        servingSize: '3 keping (30 g)',
        sugarGrams: 16,
        highlightNote: 'Gula: 16 gram (Tinggi)',
        category: 'makanan'
      }
    }
  },
  {
    id: 'IG-05',
    topic: 'MEMBACA_INFORMASI_GIZI',
    topicLabel: 'Membaca Informasi Gizi',
    difficulty: 'Sedang',
    question: 'Satu sendok teh gula pasir setara dengan kira-kira 4 gram gula. Jika sebuah minuman manis mengandung 20 gram gula, itu setara dengan...',
    options: [
      'Hanya setengah sendok teh gula.',
      'Sekitar 5 sendok teh gula pasir.',
      'Tidak ada gula sama sekali.',
      '20 sendok makan penuh.'
    ],
    correctIndex: 1,
    explanation: '20 gram dibagi 4 gram per sendok teh = 5 sendok teh gula! Membayangkan sendok teh gula membantu kita menyadari banyaknya pemanis dalam minuman kemasan.'
  },

  // --- 4. GULA DAN TUBUHKU (Fokus Utama Level 3) ---
  {
    id: 'GT-01',
    topic: 'GULA_DAN_TUBUHKU',
    topicLabel: 'Gula dan Tubuhku',
    difficulty: 'Mudah',
    question: 'Tubuh kita membutuhkan energi untuk berlari dan belajar. Dari mana tubuh memperoleh energi?',
    options: [
      'Hanya dari permen dan gula-gula.',
      'Dari berbagai makanan dan minuman bergizi yang kita konsumsi sehari-hari.',
      'Hanya dari minuman bersoda dan sirup.',
      'Hanya dari makanan yang rasanya manis saja.'
    ],
    correctIndex: 1,
    explanation: 'Energi berasal dari karbohidrat, protein, dan lemak sehat dari beragam makanan (nasi, ikan, telur, sayur, buah). Kita tidak perlu bergantung pada makanan manis.'
  },
  {
    id: 'GT-02',
    topic: 'GULA_DAN_TUBUHKU',
    topicLabel: 'Gula dan Tubuhku',
    difficulty: 'Mudah',
    question: 'Apa yang dapat terjadi jika kita terlalu sering mengonsumsi makanan dan minuman manis?',
    options: [
      'Gigi lebih mudah berlubang dan rusak.',
      'Gigi menjadi semakin putih dan kebal kuman.',
      'Tubuh tidak lagi membutuhkan makanan lain.',
      'Kita tidak akan pernah merasa haus lagi.'
    ],
    correctIndex: 0,
    explanation: 'Bakteri di mulut memakan sisa gula dan menghasilkan asam yang dapat merusak lapisan enamel gigi, sehingga gigi mudah berlubang.'
  },
  {
    id: 'GT-03',
    topic: 'GULA_DAN_TUBUHKU',
    topicLabel: 'Gula dan Tubuhku',
    difficulty: 'Sedang',
    question: 'Setelah makan permen atau camilan manis, apa yang sebaiknya kamu lakukan untuk menjaga kesehatan gigi?',
    options: [
      'Langsung makan permen lagi agar manisnya merata.',
      'Tidak perlu berkumur atau membersihkan gigi.',
      'Berkumur dengan air bersih dan menyikat gigi secara teratur.',
      'Mengunyah permen karet manis berulang kali.'
    ],
    correctIndex: 2,
    explanation: 'Berkumur dengan air bersih membantu membersihkan sisa gula yang menempel di sela gigi, dan menyikat gigi 2 kali sehari menjaga gigi tetap kuat.'
  },
  {
    id: 'GT-04',
    topic: 'GULA_DAN_TUBUHKU',
    topicLabel: 'Gula dan Tubuhku',
    difficulty: 'Sedang',
    question: 'Mengapa minum minuman yang terlalu manis terkadang justru membuat kita semakin merasa haus?',
    options: [
      'Karena kadar gula tinggi menarik air dari sel-sel tubuh sehingga tubuh meminta air tawar.',
      'Karena minuman manis mengandung garam dapur yang sangat banyak.',
      'Karena es batu di minuman manis membakar tenggorokan.',
      'Hal itu hanya mitos belaka dan tidak pernah terjadi.'
    ],
    correctIndex: 0,
    explanation: 'Kadar gula tinggi dalam darah membuat tubuh berusaha mengencerkannya dengan menarik cairan, sehingga rasa haus justru muncul kembali. Air putih adalah pereda dahaga sejati.'
  },
  {
    id: 'GT-05',
    topic: 'GULA_DAN_TUBUHKU',
    topicLabel: 'Gula dan Tubuhku',
    difficulty: 'Tantangan',
    question: 'Jika setiap hari mengonsumsi gula berlebihan dalam jangka panjang tanpa diimbangi olahraga, apa dampaknya bagi tubuh?',
    options: [
      'Tubuh menjadi lebih ringan dan cepat terbang.',
      'Dapat meningkatkan risiko kelebihan berat badan dan gangguan kesehatan saat dewasa.',
      'Tulang menjadi elastis seperti karet.',
      'Tidak ada dampak apa pun karena anak-anak bebas makan apa saja.'
    ],
    correctIndex: 1,
    explanation: 'Kelebihan gula yang tidak terpakai disimpan sebagai lemak, yang jika menumpuk terus dapat menimbulkan risiko kelebihan berat badan dan masalah metabolisme.'
  },

  // --- 5. PILIHAN MAKANAN YANG BIJAK (Fokus Utama Level 3) ---
  {
    id: 'PB-01',
    topic: 'PILIHAN_MAKANAN_BIJAK',
    topicLabel: 'Pilihan Makanan yang Bijak',
    difficulty: 'Mudah',
    question: 'Saat istirahat di sekolah, temanmu membeli minuman bersoda. Kamu juga ingin membeli minum. Apa pilihan yang bijak?',
    options: [
      'Selalu ikut-ikutan teman apa pun yang dia beli.',
      'Memilih air putih sebagai minuman segar sehari-hari.',
      'Membeli dua botol soda sekaligus agar lebih keren.',
      'Memilih minuman yang paling manis di etalase kantin.'
    ],
    correctIndex: 1,
    explanation: 'Kita bisa menjadi penjelajah mandiri yang percaya diri memilih air putih untuk kesehatan tubuh kita sendiri.'
  },
  {
    id: 'PB-02',
    topic: 'PILIHAN_MAKANAN_BIJAK',
    topicLabel: 'Pilihan Makanan yang Bijak',
    difficulty: 'Sedang',
    question: 'Ibu menyiapkan kotak bekal untuk sekolah. Bekal mana yang memiliki pilihan makanan paling seimbang dan bergizi?',
    options: [
      'Nasi, lauk telur, sayur tumis, dan potongan buah semangka.',
      'Dua bungkus permen jelly dan sebotol soda manis.',
      'Keripik renyah asin dan sekotak minuman sirup pekat.',
      'Kue donat cokelat manis dan gulali warna-warni.'
    ],
    correctIndex: 0,
    explanation: 'Makanan yang bervariasi (karbohidrat, protein, sayur, dan buah) menyediakan zat gizi lengkap yang dibutuhkan tubuh anak untuk tumbuh sehat.'
  },
  {
    id: 'PB-03',
    topic: 'PILIHAN_MAKANAN_BIJAK',
    topicLabel: 'Pilihan Makanan yang Bijak',
    difficulty: 'Sedang',
    question: 'Kamu ingin minum sesuatu yang segar setelah berolahraga di bawah terik matahari. Di rumah tersedia air putih dingin dan sirup manis. Pilihan terbaikmu adalah...',
    options: [
      'Minum sirup manis bergelas-gelas.',
      'Minum air putih untuk menggantikan cairan tubuh yang hilang lewat keringat.',
      'Tidak minum apa-apa sama sekali sampai malam.',
      'Menambahkan garam dan gula pasir ke dalam sirup.'
    ],
    correctIndex: 1,
    explanation: 'Setelah berolahraga, tubuh kehilangan air melalui keringat. Air putih adalah pilihan terbaik untuk mengembalikan hidrasi secara cepat dan bersih.'
  },
  {
    id: 'PB-04',
    topic: 'PILIHAN_MAKANAN_BIJAK',
    topicLabel: 'Pilihan Makanan yang Bijak',
    difficulty: 'Tantangan',
    question: 'Jika diajak merayakan ulang tahun teman dan disajikan kue tart serta minuman manis, sikap bijak apa yang sebaiknya kita ambil?',
    options: [
      'Menolak keras dan membuang kue pemberian teman.',
      'Menikmati sepotong kue secukupnya dan mendampinginya dengan minum air putih.',
      'Menghabiskan sepuluh potong kue sekaligus tanpa henti.',
      'Menangis karena takut melihat kue manis.'
    ],
    correctIndex: 1,
    explanation: 'Menikmati hidangan istimewa saat perayaan itu menyenangkan! Kuncinya adalah makan secukupnya, bersyukur, dan tetap mengutamakan air putih.'
  },
  {
    id: 'PB-05',
    topic: 'PILIHAN_MAKANAN_BIJAK',
    topicLabel: 'Pilihan Makanan yang Bijak',
    difficulty: 'Tantangan',
    question: 'Apa arti dari semboyan "Kenali Makanan. Pilih dengan Bijak"?',
    options: [
      'Kita dilarang makan makanan yang enak selamanya.',
      'Kita belajar mencari tahu isi kandungan makanan/minuman agar dapat menentukan pilihan sehat untuk tubuh kita.',
      'Kita hanya boleh meminum air hangat tanpa rasa apa pun.',
      'Kita harus selalu membeli makanan yang bungkusnya mahal.'
    ],
    correctIndex: 1,
    explanation: 'Menjadi cerdas berarti memahami apa yang kita konsumsi, membaca label gizi, dan membuat keputusan yang membuat tubuh kita tumbuh kuat dan bugar.'
  }
];

// Helper to get questions for specific level triggers
export function getQuestionsForLevel(levelId: number): QuestionData[] {
  switch (levelId) {
    case 1:
      // Level 1 focuses on Mengenal Minuman Manis
      return [
        QUESTION_BANK[0], // MM-01 Air putih vs soda
        QUESTION_BANK[1], // MM-02 Minuman bersoda tambahan gula
        QUESTION_BANK[2], // MM-03 Air putih di kantin
        QUESTION_BANK[3], // MM-04 Minuman boba / teh susu
        QUESTION_BANK[4], // MM-05 Kebutuhan 6-8 gelas
      ];
    case 2:
      // Level 2 focuses on Mengenal Makanan Manis & Membaca Informasi Gizi
      return [
        QUESTION_BANK[5],  // MK-01 Donat vs telur/sayur
        QUESTION_BANK[6],  // MK-02 Buah potong vs permen
        QUESTION_BANK[10], // IG-01 Minuman A (8g) vs B (18g)
        QUESTION_BANK[11], // IG-02 Membaca informasi gizi
        QUESTION_BANK[13], // IG-04 Biskuit (4g) vs Wafer (16g)
      ];
    case 3:
      // Level 3 focuses on Gula dan Tubuhku & Pilihan Makanan Bijak
      return [
        QUESTION_BANK[15], // GT-01 Sumber energi beragam
        QUESTION_BANK[16], // GT-02 Gigi berlubang
        QUESTION_BANK[17], // GT-03 Berkumur & sikat gigi
        QUESTION_BANK[20], // PB-01 Percaya diri pilih air putih
        QUESTION_BANK[21], // PB-02 Bekal bergizi seimbang
        QUESTION_BANK[24], // PB-05 Makna semboyan Guligo
      ];
    default:
      return QUESTION_BANK.slice(0, 5);
  }
}
