// Main Application Container for GULIGO! FOOD ADVENTURE
// State machine coordination, persistent GameEngine lifecycle across challenges, and progression

import React, { useState, useEffect, useRef } from 'react';
import { GameScreen, QuestionTrigger, NPC, QuestionData, PlayerAnswerRecord, SavedProgress } from './types/game';
import { LEVELS } from './game/levels';
import { QUESTION_BANK } from './data/questions';
import { GameEngine } from './game/engine';
import { GameHUD } from './components/GameHUD';
import { QuestionModal } from './components/QuestionModal';
import { NPCDialogueModal } from './components/NPCDialogueModal';
import { PauseModal } from './components/PauseModal';
import { LevelCompletedModal } from './components/LevelCompletedModal';
import { FinalResultsModal } from './components/FinalResultsModal';
import { MainMenu } from './components/MainMenu';
import { HowToPlayModal } from './components/HowToPlayModal';
import { SettingsModal } from './components/SettingsModal';
import { CreditsModal } from './components/CreditsModal';
import { LevelSelectModal } from './components/LevelSelectModal';
import { TeacherDashboardModal } from './components/TeacherDashboardModal';
import { TeacherAuthModal } from './components/TeacherAuthModal';
import { getSavedProgress, saveProgress, saveGameSession } from './utils/storage';
import { soundManager } from './utils/audio';

export default function App() {
  // Screen state
  const [screen, setScreen] = useState<GameScreen>('MAIN_MENU');

  // Active level execution state (controls GameEngine lifecycle, distinct from screen overlays)
  const [activeGameLevel, setActiveGameLevel] = useState<number | null>(null);
  const [levelRunId, setLevelRunId] = useState<number>(0);

  // Progress state
  const [progress, setProgress] = useState<SavedProgress>(() => getSavedProgress());
  const [currentLevelId, setCurrentLevelId] = useState<number>(1);

  // Teacher authentication state (PIN: 1111)
  const [isTeacherAuthenticated, setIsTeacherAuthenticated] = useState<boolean>(false);
  const [showTeacherAuthModal, setShowTeacherAuthModal] = useState<boolean>(false);

  // In-game dynamic modal triggers
  const [activeQuestion, setActiveQuestion] = useState<QuestionData | null>(null);
  const [activeNPC, setActiveNPC] = useState<NPC | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<number | null>(null);

  // Session metrics across the entire adventure
  const [sessionScore, setSessionScore] = useState<number>(0);
  const [sessionCoins, setSessionCoins] = useState<number>(0);
  const [sessionAnswers, setSessionAnswers] = useState<PlayerAnswerRecord[]>([]);
  const [levelStartScore, setLevelStartScore] = useState<number>(0);
  const [levelStartCoins, setLevelStartCoins] = useState<number>(0);

  // Canvas & GameEngine references
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // In-game HUD stats
  const [hudLives, setHudLives] = useState<number>(3);
  const [hudCoins, setHudCoins] = useState<number>(0);
  const [hudScore, setHudScore] = useState<number>(0);
  const [hudQuestionsAnswered, setHudQuestionsAnswered] = useState<number>(0);

  const currentLevelData = LEVELS.find((l) => l.id === currentLevelId) || LEVELS[0];

  const showToast = (msg: string) => {
    setToastMessage(msg);
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    toastTimeoutRef.current = window.setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Resize canvas to match screen dimensions
  const updateCanvasSize = () => {
    if (canvasRef.current) {
      canvasRef.current.width = window.innerWidth;
      canvasRef.current.height = window.innerHeight;
    }
  };

  useEffect(() => {
    window.addEventListener('resize', updateCanvasSize);
    return () => window.removeEventListener('resize', updateCanvasSize);
  }, []);

  // Initialize GameEngine ONLY when entering a level or explicitly restarting it.
  // CRITICAL: Must NOT re-trigger when opening/closing Question or NPC modals!
  useEffect(() => {
    if (activeGameLevel === null) return;
    if (!canvasRef.current) return;

    updateCanvasSize();

    setLevelStartScore(sessionScore);
    setLevelStartCoins(sessionCoins);

    const levelData = LEVELS.find((l) => l.id === activeGameLevel) || LEVELS[0];

    const engine = new GameEngine(
      canvasRef.current,
      levelData,
      {
        onQuestionTrigger: (trigger: QuestionTrigger) => {
          const foundQ = QUESTION_BANK.find((q) => q.id === trigger.questionId);
          if (foundQ) {
            setActiveQuestion(foundQ);
            setScreen('QUESTION_ACTIVE');
          }
        },
        onNPCDialogue: (npc: NPC) => {
          setActiveNPC(npc);
          setScreen('NPC_DIALOGUE');
        },
        onLevelComplete: () => {
          setHudLives(engine.player.lives);
          setHudScore(engine.player.score);
          setHudCoins(engine.player.coins);
          setSessionScore(engine.player.score);
          setSessionCoins(engine.player.coins);

          // Unlock next level in progress
          const nextLvl = activeGameLevel + 1;
          const updated = saveProgress({
            unlockedLevel: Math.max(progress.unlockedLevel, nextLvl),
            highScore: Math.max(progress.highScore, engine.player.score),
            totalCoins: progress.totalCoins + (engine.player.coins - levelStartCoins),
          });
          setProgress(updated);

          setScreen('LEVEL_CLEAR');
        },
        onCheckpointReached: (name: string) => {
          showToast(`Pos Pemeriksaan: ${name}!`);
        },
        onPlayerHurt: (remaining: number) => {
          setHudLives(remaining);
          showToast('Hati-hati! Hindari rintangan manis!');
        },
        onCoinsChanged: (coins: number, score: number) => {
          setHudCoins(coins);
          setHudScore(score);
          setSessionCoins(coins);
          setSessionScore(score);
        },
        onExitLocked: (completed: number, total: number) => {
          showToast(`Jawab semua Tugu Pengetahuan (${completed}/${total}) untuk membuka Gerbang Keluar!`);
        },
      },
      sessionCoins,
      sessionScore
    );

    engineRef.current = engine;
    setHudLives(engine.player.lives);
    setHudCoins(engine.player.coins);
    setHudScore(engine.player.score);
    setHudQuestionsAnswered(0);

    engine.start();

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, [activeGameLevel, levelRunId]);

  // Handle Question Answering
  const handleAnswerQuestion = (isCorrect: boolean, chosenIndex: number) => {
    if (!activeQuestion) return;

    // Record answer for learning analytics
    const record: PlayerAnswerRecord = {
      questionId: activeQuestion.id,
      topic: activeQuestion.topic,
      topicLabel: activeQuestion.topicLabel,
      question: activeQuestion.question,
      chosenIndex,
      correctIndex: activeQuestion.correctIndex,
      isCorrect,
      timestamp: Date.now(),
    };
    setSessionAnswers((prev) => [...prev, record]);

    if (engineRef.current) {
      if (isCorrect) {
        engineRef.current.player.score += 100;
        setHudScore(engineRef.current.player.score);
        setSessionScore(engineRef.current.player.score);
      }

      // Mark the active question trigger as completed in engine
      const trigger = engineRef.current.level.questionTriggers.find(
        (t) => t.questionId === activeQuestion.id
      );
      if (trigger) {
        trigger.triggered = true;
        trigger.answeredCorrectly = isCorrect;
      }

      const completedCount = engineRef.current.level.questionTriggers.filter((t) => t.triggered).length;
      const totalCount = engineRef.current.level.questionTriggers.length;
      setHudQuestionsAnswered(completedCount);

      if (completedCount >= totalCount) {
        showToast('Semua Tantangan Selesai! Gerbang Keluar telah Terbuka! ▶');
      } else {
        showToast(`Tantangan Terjawab! (${completedCount}/${totalCount})`);
      }
    }
  };

  // Close question modal and seamlessly RESUME the platformer where the player stopped
  const handleCloseQuestionModal = () => {
    setActiveQuestion(null);
    setScreen('PLAYING');
    if (engineRef.current) {
      engineRef.current.resume();
    }
  };

  // Close NPC dialogue and seamlessly RESUME the platformer
  const handleCloseNPCDialogue = () => {
    setActiveNPC(null);
    setScreen('PLAYING');
    if (engineRef.current) {
      engineRef.current.resume();
    }
  };

  const handlePause = () => {
    if (engineRef.current) {
      engineRef.current.pause();
    }
    setScreen('PAUSED');
  };

  const handleResume = () => {
    setScreen('PLAYING');
    if (engineRef.current) {
      engineRef.current.resume();
    }
  };

  const handleRestartLevel = () => {
    setSessionScore(levelStartScore);
    setSessionCoins(levelStartCoins);
    setLevelRunId((prev) => prev + 1);
    setScreen('PLAYING');
  };

  const handleMainMenu = () => {
    if (engineRef.current) {
      engineRef.current.stop();
      engineRef.current.destroy();
      engineRef.current = null;
    }
    soundManager.stopBGM();
    setActiveGameLevel(null);
    setScreen('MAIN_MENU');
  };

  const handleStartGame = (startLevel: number = 1) => {
    setCurrentLevelId(startLevel);
    setSessionScore(0);
    setSessionCoins(0);
    setSessionAnswers([]);
    setActiveGameLevel(startLevel);
    setLevelRunId((prev) => prev + 1);
    setScreen('PLAYING');
  };

  const handleNextLevel = () => {
    if (currentLevelId < LEVELS.length) {
      const nextLevel = currentLevelId + 1;
      setCurrentLevelId(nextLevel);
      setActiveGameLevel(nextLevel);
      setLevelRunId((prev) => prev + 1);
      setScreen('PLAYING');
    } else {
      // Completed all 3 levels! Save session and show final results
      saveGameSession(sessionScore, sessionCoins, sessionAnswers, 3);
      if (engineRef.current) {
        engineRef.current.stop();
        engineRef.current.destroy();
        engineRef.current = null;
      }
      setActiveGameLevel(null);
      setScreen('FINAL_RESULTS');
    }
  };

  const handleOpenTeacherDashboard = () => {
    if (isTeacherAuthenticated) {
      setScreen('TEACHER_DASHBOARD');
    } else {
      setShowTeacherAuthModal(true);
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-900 font-body">
      {/* Canvas World (Active during gameplay and pauses, hidden on main menu) */}
      <canvas
        ref={canvasRef}
        className={`w-full h-full block touch-none ${
          activeGameLevel === null ? 'hidden' : 'block'
        }`}
      />

      {/* In-Game HUD overlay */}
      {activeGameLevel !== null && (screen === 'PLAYING' || screen === 'QUESTION_ACTIVE' || screen === 'NPC_DIALOGUE') && (
        <GameHUD
          levelTitle={currentLevelData.title}
          lives={hudLives}
          maxLives={3}
          coins={hudCoins}
          score={hudScore}
          completedQuestions={hudQuestionsAnswered}
          totalQuestions={currentLevelData.questionTriggers.length}
          onPause={handlePause}
          onTouchAction={(action, active) => {
            if (engineRef.current) {
              engineRef.current.setTouchInput(action, active);
            }
          }}
          toastMessage={toastMessage}
        />
      )}

      {/* Main Menu Screen */}
      {screen === 'MAIN_MENU' && (
        <MainMenu
          onStartGame={() => handleStartGame(1)}
          onOpenLevelSelect={() => setScreen('LEVEL_SELECT')}
          onOpenHowToPlay={() => setScreen('HOW_TO_PLAY')}
          onOpenSettings={() => setScreen('SETTINGS')}
          onOpenTeacherDashboard={handleOpenTeacherDashboard}
          onOpenCredits={() => setScreen('CREDITS')}
          unlockedLevel={progress.unlockedLevel}
          highScore={progress.highScore}
          totalCoins={progress.totalCoins}
        />
      )}

      {/* Level Select Modal */}
      {screen === 'LEVEL_SELECT' && (
        <LevelSelectModal
          unlockedLevel={progress.unlockedLevel}
          onSelectLevel={(lvlId) => handleStartGame(lvlId)}
          onClose={() => setScreen('MAIN_MENU')}
        />
      )}

      {/* How to Play Tutorial Modal */}
      {screen === 'HOW_TO_PLAY' && (
        <HowToPlayModal onClose={() => setScreen('MAIN_MENU')} />
      )}

      {/* Settings Modal */}
      {screen === 'SETTINGS' && (
        <SettingsModal onClose={() => setScreen(activeGameLevel !== null ? 'PAUSED' : 'MAIN_MENU')} />
      )}

      {/* Credits Modal */}
      {screen === 'CREDITS' && (
        <CreditsModal onClose={() => setScreen('MAIN_MENU')} />
      )}

      {/* Teacher PIN Authentication Modal */}
      {showTeacherAuthModal && (
        <TeacherAuthModal
          onSuccess={() => {
            setIsTeacherAuthenticated(true);
            setShowTeacherAuthModal(false);
            setScreen('TEACHER_DASHBOARD');
          }}
          onCancel={() => setShowTeacherAuthModal(false)}
        />
      )}

      {/* Teacher Dashboard Modal */}
      {screen === 'TEACHER_DASHBOARD' && (
        <TeacherDashboardModal
          onClose={() => setScreen('MAIN_MENU')}
          onLogout={() => {
            setIsTeacherAuthenticated(false);
            setScreen('MAIN_MENU');
          }}
        />
      )}

      {/* Pause Menu Modal */}
      {screen === 'PAUSED' && (
        <PauseModal
          onResume={handleResume}
          onRestartLevel={handleRestartLevel}
          onMainMenu={handleMainMenu}
          onOpenSettings={() => setScreen('SETTINGS')}
        />
      )}

      {/* NPC Dialogue Modal */}
      {screen === 'NPC_DIALOGUE' && activeNPC && (
        <NPCDialogueModal npc={activeNPC} onClose={handleCloseNPCDialogue} />
      )}

      {/* Educational Question Challenge Modal */}
      {screen === 'QUESTION_ACTIVE' && activeQuestion && (
        <QuestionModal
          question={activeQuestion}
          onAnswer={handleAnswerQuestion}
          onClose={handleCloseQuestionModal}
        />
      )}

      {/* Level Completion Modal */}
      {screen === 'LEVEL_CLEAR' && (
        <LevelCompletedModal
          levelNumber={currentLevelId}
          levelTitle={currentLevelData.title}
          scoreGained={sessionScore - levelStartScore}
          coinsGained={sessionCoins - levelStartCoins}
          questionsAnswered={currentLevelData.questionTriggers.length}
          hasNextLevel={currentLevelId < LEVELS.length}
          onNextLevel={handleNextLevel}
          onMainMenu={handleMainMenu}
        />
      )}

      {/* Final Results & Learning Summary Screen */}
      {screen === 'FINAL_RESULTS' && (
        <FinalResultsModal
          totalScore={sessionScore}
          totalCoins={sessionCoins}
          correctCount={sessionAnswers.filter((a) => a.isCorrect).length}
          incorrectCount={sessionAnswers.filter((a) => !a.isCorrect).length}
          completedLevels={3}
          onPlayAgain={() => handleStartGame(1)}
          onOpenTeacherDashboard={handleOpenTeacherDashboard}
          onMainMenu={handleMainMenu}
        />
      )}
    </div>
  );
}
