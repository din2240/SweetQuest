// How to Play Tutorial Modal for SweetQuest
// Clear, child-friendly explanations in Bahasa Indonesia with pastel strawberry visual design

import React from 'react';
import { CoinIcon, NutritionLabelIcon, QuestionCircleIcon, FlagIcon } from './GameIcons';
import { soundManager } from '../utils/audio';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-purple-950/60 backdrop-blur-md overflow-y-auto animate-fade-in select-none">
      <div className="w-full max-w-2xl bg-[#fffbfd] rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-500 via-pink-600 to-purple-600 text-white px-6 py-4 flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-widest text-pink-200 font-bold block">
              Panduan Petualang Cilik
            </span>
            <h1 className="text-xl md:text-2xl font-bold font-heading">Petunjuk Bermain</h1>
          </div>
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onClose();
            }}
            className="px-3.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold"
          >
            Tutup [✕]
          </button>
        </div>

        {/* Content */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-4">
          {/* Movement & Controls */}
          <div className="bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm space-y-2">
            <h2 className="text-sm font-bold text-purple-950 font-heading">
              1. Cara Menggerakkan Karakter
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-purple-950">
              <div className="bg-pink-50/60 p-3 rounded-xl border border-pink-200 space-y-1">
                <span className="font-bold text-rose-700 block">Keyboard (Komputer / Laptop)</span>
                <p>• Bergerak ke kiri / kanan: Tombol <b>Panah [←] [→]</b> atau tombol <b>[A] [D]</b></p>
                <p>• Melompat: Tombol <b>Spasi</b>, <b>Panah [↑]</b>, atau <b>[W]</b></p>
                <p>• Berinteraksi / Bicara: Tombol <b>[E]</b> atau <b>[Enter]</b></p>
              </div>

              <div className="bg-purple-50/60 p-3 rounded-xl border border-purple-200 space-y-1">
                <span className="font-bold text-purple-800 block">Layar Sentuh (HP / Tablet)</span>
                <p>• Sentuh tombol <b>[←]</b> dan <b>[→]</b> di kiri bawah untuk bergerak</p>
                <p>• Sentuh tombol merah muda <b>[Lompat]</b> di kanan bawah</p>
                <p>• Sentuh tombol ungu <b>[Bicara]</b> saat berada dekat teman atau tugu</p>
              </div>
            </div>
          </div>

          {/* Core Objectives */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Coins & Scores */}
            <div className="bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm space-y-1.5">
              <div className="flex items-center gap-2">
                <CoinIcon className="w-5 h-5" />
                <h3 className="text-sm font-bold text-purple-950 font-heading">
                  2. Kumpulkan Koin Stroberi
                </h3>
              </div>
              <p className="text-xs text-purple-900/80 leading-relaxed">
                Jelajahi setiap jembatan wafer dan dahan buah untuk mengumpulkan koin emas stroberi dan menambah skormu.
              </p>
            </div>

            {/* Checkpoints */}
            <div className="bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm space-y-1.5">
              <div className="flex items-center gap-2">
                <FlagIcon className="w-5 h-5 text-pink-600" />
                <h3 className="text-sm font-bold text-purple-950 font-heading">
                  3. Sentuh Pos Pemeriksaan
                </h3>
              </div>
              <p className="text-xs text-purple-900/80 leading-relaxed">
                Saat melewati bendera pos pemeriksaan, posisimu akan tersimpan. Jika terkena rintangan, kamu akan kembali ke pos terdekat.
              </p>
            </div>
          </div>

          {/* Question Shrines & Nutrition Labels */}
          <div className="bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm space-y-2">
            <div className="flex items-center gap-2">
              <QuestionCircleIcon className="w-5 h-5 text-purple-600" />
              <h3 className="text-sm font-bold text-purple-950 font-heading">
                4. Jawab Tantangan di Tugu Pengetahuan
              </h3>
            </div>
            <p className="text-xs text-purple-900/80 leading-relaxed">
              Di sepanjang perjalanan, sentuh Tugu Pengetahuan bersinar untuk membuka pertanyaan seputar makanan dan minuman sehat.
            </p>
            <div className="bg-pink-50/80 p-3 rounded-xl border border-pink-200 text-xs text-purple-950 flex items-start gap-2.5">
              <NutritionLabelIcon className="w-5 h-5 text-pink-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-rose-800 block">Tips Membaca Informasi Nilai Gizi:</span>
                Perhatikan angka <b>gram gula</b> pada kemasan. Ingat: 1 sendok teh kira-kira sama dengan 4 gram gula! Pilihlah minuman atau makanan yang rendah gula tambahan.
              </div>
            </div>
          </div>

          {/* Completing the Level */}
          <div className="bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm space-y-1.5">
            <h3 className="text-sm font-bold text-purple-950 font-heading">
              5. Membuka Gerbang Keluar
            </h3>
            <p className="text-xs text-purple-900/80 leading-relaxed">
              Setelah semua Tugu Pengetahuan di suatu level berhasil dijawab, Gerbang Rumah Kue yang bersinar akan terbuka untuk mengantarmu ke level berikutnya!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-pink-50 px-6 py-3.5 border-t border-pink-200 flex justify-end">
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onClose();
            }}
            className="px-6 py-2.5 rounded-2xl font-bold font-heading text-sm bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shadow-md active:scale-95 transition-all"
          >
            Saya Siap Berpetualang! →
          </button>
        </div>
      </div>
    </div>
  );
};
