// Audio & Gameplay Settings Modal for SweetQuest
// Pastel strawberry and lavender styling

import React, { useState } from 'react';
import { VolumeOnIcon, VolumeMuteIcon } from './GameIcons';
import { soundManager } from '../utils/audio';
import { AudioSettings } from '../types/game';

interface SettingsModalProps {
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
  const [settings, setSettings] = useState<AudioSettings>({ ...soundManager.settings });

  const handleToggleBgm = () => {
    const next = !settings.bgmEnabled;
    const updated = { ...settings, bgmEnabled: next };
    setSettings(updated);
    soundManager.saveSettings(updated);
    soundManager.playSFX('click');
  };

  const handleToggleSfx = () => {
    const next = !settings.sfxEnabled;
    const updated = { ...settings, sfxEnabled: next };
    setSettings(updated);
    soundManager.saveSettings(updated);
    soundManager.playSFX('click');
  };

  const handleBgmVolume = (val: number) => {
    const updated = { ...settings, bgmVolume: val };
    setSettings(updated);
    soundManager.saveSettings(updated);
  };

  const handleSfxVolume = (val: number) => {
    const updated = { ...settings, sfxVolume: val };
    setSettings(updated);
    soundManager.saveSettings(updated);
    soundManager.playSFX('click');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/60 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-md bg-[#fffbfd] rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-500 via-pink-600 to-purple-600 text-white px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold font-heading">Pengaturan Suara</h2>
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onClose();
            }}
            className="px-3 py-1 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Background Music (BGM) */}
          <div className="bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {settings.bgmEnabled ? (
                  <VolumeOnIcon className="w-5 h-5 text-rose-500" />
                ) : (
                  <VolumeMuteIcon className="w-5 h-5 text-purple-300" />
                )}
                <span className="text-sm font-bold text-purple-950 font-heading">Musik Latar</span>
              </div>
              <button
                onClick={handleToggleBgm}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                  settings.bgmEnabled
                    ? 'bg-rose-500 text-white'
                    : 'bg-purple-100 text-purple-600'
                }`}
              >
                {settings.bgmEnabled ? 'Nyala' : 'Mati'}
              </button>
            </div>

            {/* Volume slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-purple-900/70">
                <span>Volume Musik</span>
                <span className="font-mono">{Math.round(settings.bgmVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.bgmVolume}
                onChange={(e) => handleBgmVolume(parseFloat(e.target.value))}
                disabled={!settings.bgmEnabled}
                className="w-full accent-rose-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Sound Effects (SFX) */}
          <div className="bg-white p-4 rounded-2xl border-2 border-purple-100 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {settings.sfxEnabled ? (
                  <VolumeOnIcon className="w-5 h-5 text-purple-600" />
                ) : (
                  <VolumeMuteIcon className="w-5 h-5 text-purple-300" />
                )}
                <span className="text-sm font-bold text-purple-950 font-heading">Efek Suara</span>
              </div>
              <button
                onClick={handleToggleSfx}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                  settings.sfxEnabled
                    ? 'bg-purple-600 text-white'
                    : 'bg-purple-100 text-purple-600'
                }`}
              >
                {settings.sfxEnabled ? 'Nyala' : 'Mati'}
              </button>
            </div>

            {/* Volume slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-purple-900/70">
                <span>Volume Efek</span>
                <span className="font-mono">{Math.round(settings.sfxVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.sfxVolume}
                onChange={(e) => handleSfxVolume(parseFloat(e.target.value))}
                disabled={!settings.sfxEnabled}
                className="w-full accent-purple-600 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-pink-50 px-6 py-3.5 border-t border-pink-200 flex justify-end">
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onClose();
            }}
            className="px-6 py-2 rounded-2xl font-bold font-heading text-sm bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shadow-md active:scale-95 transition-all"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};
