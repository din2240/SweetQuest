import React from 'react';
import { soundManager } from '../utils/audio';

interface PauseModalProps {
  onResume: () => void;
  onRestartLevel: () => void;
  onMainMenu: () => void;
  onOpenSettings: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestartLevel,
  onMainMenu,
  onOpenSettings,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/60 backdrop-blur-sm animate-fade-in select-none">
      <div className="w-full max-w-sm bg-pink-50 rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden text-center p-6 space-y-4">
        {/* Header Icon & Title */}
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-400 to-rose-400 flex items-center justify-center text-2xl shadow-md mb-2">
            🍓
          </div>
          <span className="text-xs font-bold text-pink-600 uppercase tracking-widest block">
            Permainan Dijeda
          </span>
          <h2 className="text-2xl font-bold font-heading text-purple-950">Istirahat Sejenak</h2>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5 pt-2">
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onResume();
            }}
            className="w-full py-3.5 px-4 rounded-2xl font-bold font-heading text-base bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shadow-md active:scale-95 transition-all"
          >
            Lanjutkan Permainan
          </button>

          <button
            onClick={() => {
              soundManager.playSFX('click');
              onRestartLevel();
            }}
            className="w-full py-2.5 px-4 rounded-2xl font-semibold text-sm bg-purple-100 hover:bg-purple-200 text-purple-950 border border-purple-200 transition-all"
          >
            Ulangi Level Ini
          </button>

          <button
            onClick={() => {
              soundManager.playSFX('click');
              onOpenSettings();
            }}
            className="w-full py-2.5 px-4 rounded-2xl font-semibold text-sm bg-white hover:bg-pink-50 text-purple-900 border border-purple-200 transition-all"
          >
            Pengaturan Suara
          </button>

          <button
            onClick={() => {
              soundManager.playSFX('click');
              onMainMenu();
            }}
            className="w-full py-2.5 px-4 rounded-2xl font-semibold text-sm bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 transition-all"
          >
            Kembali ke Menu Utama
          </button>
        </div>
      </div>
    </div>
  );
};

