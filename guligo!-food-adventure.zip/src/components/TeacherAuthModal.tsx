// Teacher PIN Authentication Modal for SweetQuest
// Protects the Teacher Dashboard with PIN: 1111
// All Indonesian labels and required error message: "PIN yang Anda masukkan tidak sesuai."

import React, { useState } from 'react';
import { soundManager } from '../utils/audio';

interface TeacherAuthModalProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export const TeacherAuthModal: React.FC<TeacherAuthModalProps> = ({ onSuccess, onCancel }) => {
  const [pin, setPin] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playSFX('click');

    // Expected teacher PIN
    if (pin.trim() === '1111') {
      setErrorMessage(null);
      soundManager.playSFX('correct');
      onSuccess();
    } else {
      soundManager.playSFX('incorrect');
      setErrorMessage('PIN yang Anda masukkan tidak sesuai.');
      setPin('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/60 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border-4 border-pink-200 overflow-hidden text-center">
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-purple-700 via-purple-600 to-pink-600 text-white px-6 py-5">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center mb-2 shadow-inner">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-7 h-7 text-pink-200"
            >
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </div>
          <span className="text-xs uppercase tracking-widest text-pink-200 font-bold block">
            Akses Khusus Guru
          </span>
          <h2 className="text-2xl font-bold font-heading text-white">Login Dashboard Guru</h2>
        </div>

        {/* Content & PIN Input Form */}
        <form onSubmit={handleSubmit} className="p-6 md:p-7 space-y-4">
          <p className="text-xs md:text-sm text-purple-900/80 leading-relaxed">
            Halaman ini khusus untuk pendidik guna memantau riwayat permainan, statistik pemahaman gizi, dan mengunduh data evaluasi siswa.
          </p>

          <div className="space-y-2 text-left">
            <label className="text-xs font-bold text-purple-950 block">
              Masukkan PIN Guru:
            </label>
            <input
              type="password"
              inputMode="numeric"
              maxLength={8}
              value={pin}
              onChange={(e) => {
                setPin(e.target.value);
                if (errorMessage) setErrorMessage(null);
              }}
              placeholder="Masukkan 4 digit PIN"
              autoFocus
              className="w-full px-4 py-3 rounded-2xl border-2 border-purple-200 focus:border-pink-500 focus:outline-none text-center font-mono text-xl tracking-widest text-purple-950 bg-pink-50/40"
            />
          </div>

          {/* Exact required error message */}
          {errorMessage && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-300 text-rose-800 text-xs font-bold animate-bounce">
              {errorMessage}
            </div>
          )}

          {/* Actions */}
          <div className="space-y-2 pt-2">
            <button
              type="submit"
              className="w-full py-3.5 px-4 rounded-2xl font-bold font-heading text-base bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white shadow-md active:scale-95 transition-all"
            >
              Buka Dashboard Guru →
            </button>

            <button
              type="button"
              onClick={() => {
                soundManager.playSFX('click');
                onCancel();
              }}
              className="w-full py-2.5 px-4 rounded-2xl font-semibold text-xs text-purple-800 hover:bg-purple-50 border border-purple-200 transition-colors"
            >
              Kembali ke Halaman Utama
            </button>
          </div>

          {/* Security Transparency Note */}
          <p className="text-[10px] text-slate-600 pt-2 border-t border-purple-100 leading-tight">
            Catatan Keamanan: Pemeriksaan PIN di sisi peramban ini merupakan pembatasan akses sederhana untuk perangkat lokal. Jika dihosting secara daring publik, autentikasi sisi server disarankan.
          </p>
        </form>
      </div>
    </div>
  );
};
