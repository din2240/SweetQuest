// Educational Question & Nutrition Challenge Modal for SweetQuest
// Strawberry Shortcake inspired pastel aesthetic with clear nutrition label comparisons

import React, { useState } from 'react';
import { QuestionData } from '../types/game';
import { CheckCircleIcon, QuestionCircleIcon, NutritionLabelIcon } from './GameIcons';
import { soundManager } from '../utils/audio';

interface QuestionModalProps {
  question: QuestionData;
  onAnswer: (isCorrect: boolean, chosenIndex: number) => void;
  onClose: () => void;
}

export const QuestionModal: React.FC<QuestionModalProps> = ({ question, onAnswer, onClose }) => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [hasSubmitted, setHasSubmitted] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);

  const handleSelect = (index: number) => {
    if (hasSubmitted) return;
    setSelectedIndex(index);
    soundManager.playSFX('click');
  };

  const handleSubmit = () => {
    if (selectedIndex === null || hasSubmitted) return;
    const correct = selectedIndex === question.correctIndex;
    setIsCorrect(correct);
    setHasSubmitted(true);

    if (correct) {
      soundManager.playSFX('correct');
    } else {
      soundManager.playSFX('incorrect');
    }

    onAnswer(correct, selectedIndex);
  };

  const handleContinue = () => {
    soundManager.playSFX('click');
    onClose();
  };

  const handleTryAgain = () => {
    setHasSubmitted(false);
    setSelectedIndex(null);
    soundManager.playSFX('click');
  };

  const optionLabels = ['A', 'B', 'C', 'D'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-purple-950/60 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-2xl bg-[#fffbfd] rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header bar */}
        <div className="bg-gradient-to-r from-rose-500 via-pink-600 to-purple-600 px-5 py-3.5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <QuestionCircleIcon className="w-6 h-6 text-pink-200" />
            <div>
              <span className="text-xs uppercase tracking-wider font-semibold text-pink-100 block">
                Tantangan Edukasi
              </span>
              <h2 className="text-base md:text-lg font-bold font-heading">{question.topicLabel}</h2>
            </div>
          </div>
          <span className="text-xs font-semibold bg-white/20 px-3 py-1 rounded-full border border-white/30">
            Tingkat: {question.difficulty}
          </span>
        </div>

        {/* Modal content area */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-4">
          {/* Question text */}
          <div className="bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm">
            <p className="text-base md:text-lg font-bold text-purple-950 leading-snug">
              {question.question}
            </p>
          </div>

          {/* Nutrition Label Comparison (if available in this question) */}
          {question.nutritionComparison && (
            <div className="bg-pink-50/70 p-3.5 rounded-2xl border-2 border-pink-200">
              <div className="flex items-center gap-2 mb-2 text-xs font-bold text-pink-900 uppercase tracking-wide">
                <NutritionLabelIcon className="w-4 h-4 text-pink-700" />
                <span>Kartu Informasi Nilai Gizi</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Item A */}
                <div className="bg-white p-3 rounded-xl border border-pink-200 shadow-sm text-left">
                  <div className="text-xs font-bold text-purple-900 mb-1">
                    {question.nutritionComparison.itemA.name}
                  </div>
                  <div className="text-[11px] text-purple-700/70 mb-2">
                    Takaran saji: {question.nutritionComparison.itemA.servingSize}
                  </div>
                  <div className="bg-pink-50 border border-pink-200 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-xs font-semibold text-purple-900">Kandungan Gula</span>
                    <span className="text-sm font-bold text-rose-700 font-mono">
                      {question.nutritionComparison.itemA.sugarGrams} gram
                    </span>
                  </div>
                </div>

                {/* Item B */}
                <div className="bg-white p-3 rounded-xl border border-purple-200 shadow-sm text-left">
                  <div className="text-xs font-bold text-purple-900 mb-1">
                    {question.nutritionComparison.itemB.name}
                  </div>
                  <div className="text-[11px] text-purple-700/70 mb-2">
                    Takaran saji: {question.nutritionComparison.itemB.servingSize}
                  </div>
                  <div className="bg-purple-50 border border-purple-200 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-xs font-semibold text-purple-900">Kandungan Gula</span>
                    <span className="text-sm font-bold text-purple-800 font-mono">
                      {question.nutritionComparison.itemB.sugarGrams} gram
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Answer Options */}
          <div className="space-y-2.5">
            {question.options.map((option, idx) => {
              let btnClass = 'bg-white hover:bg-pink-50/60 border-purple-100 text-purple-950';

              if (selectedIndex === idx && !hasSubmitted) {
                btnClass = 'bg-pink-50 border-pink-400 text-pink-950 ring-2 ring-pink-300';
              }

              if (hasSubmitted) {
                if (idx === question.correctIndex) {
                  btnClass = 'bg-emerald-50 border-emerald-400 text-emerald-950 ring-2 ring-emerald-300';
                } else if (selectedIndex === idx && !isCorrect) {
                  btnClass = 'bg-rose-50 border-rose-300 text-rose-950';
                } else {
                  btnClass = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  disabled={hasSubmitted}
                  className={`w-full text-left p-3.5 rounded-2xl border-2 transition-all duration-150 flex items-center gap-3 ${btnClass}`}
                >
                  <span
                    className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 font-heading ${
                      selectedIndex === idx
                        ? 'bg-pink-500 text-white'
                        : 'bg-purple-100 text-purple-900'
                    }`}
                  >
                    {optionLabels[idx]}
                  </span>
                  <span className="text-sm md:text-base font-medium flex-1">{option}</span>
                </button>
              );
            })}
          </div>

          {/* Feedback Explanation Box */}
          {hasSubmitted && (
            <div
              className={`p-4 rounded-2xl border-2 transition-all animate-fade-in ${
                isCorrect
                  ? 'bg-pink-50 border-pink-300 text-pink-950'
                  : 'bg-purple-50 border-purple-300 text-purple-950'
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                {isCorrect ? (
                  <>
                    <CheckCircleIcon className="w-5 h-5 text-rose-500" />
                    <span className="font-bold font-heading text-rose-700 text-base">
                      Luar Biasa! Jawabanmu Benar (+100 Poin)
                    </span>
                  </>
                ) : (
                  <>
                    <span className="w-5 h-5 rounded-full bg-purple-400 text-white font-bold flex items-center justify-center text-xs">
                      i
                    </span>
                    <span className="font-bold font-heading text-purple-900 text-base">
                      Ayo Pahami Bersama!
                    </span>
                  </>
                )}
              </div>
              <p className="text-xs md:text-sm text-purple-900/90 leading-relaxed">
                {question.explanation}
              </p>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="bg-pink-50 px-5 py-3 border-t border-pink-200 flex items-center justify-end gap-3">
          {!hasSubmitted ? (
            <button
              onClick={handleSubmit}
              disabled={selectedIndex === null}
              className={`px-6 py-2.5 rounded-2xl font-bold font-heading text-sm md:text-base shadow-md transition-all ${
                selectedIndex !== null
                  ? 'bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white active:scale-95'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              Periksa Jawaban
            </button>
          ) : (
            <div className="flex items-center gap-2">
              {!isCorrect && (
                <button
                  onClick={handleTryAgain}
                  className="px-4 py-2.5 rounded-2xl font-semibold text-sm bg-white hover:bg-purple-50 text-purple-800 border border-purple-200"
                >
                  Coba Jawab Lagi
                </button>
              )}
              <button
                onClick={handleContinue}
                className="px-6 py-2.5 rounded-2xl font-bold font-heading text-sm md:text-base bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shadow-md active:scale-95"
              >
                Lanjutkan Petualangan →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
