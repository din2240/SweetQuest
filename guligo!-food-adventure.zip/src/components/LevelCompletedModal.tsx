import React from 'react';
import { TrophyIcon, CoinIcon, CheckCircleIcon } from './GameIcons';
import { soundManager } from '../utils/audio';

interface LevelCompletedModalProps {
  levelNumber: number;
  levelTitle: string;
  scoreGained: number;
  coinsGained: number;
  questionsAnswered: number;
  hasNextLevel: boolean;
  onNextLevel: () => void;
  onMainMenu: () => void;
}

export const LevelCompletedModal: React.FC<LevelCompletedModalProps> = ({
  levelNumber,
  levelTitle,
  scoreGained,
  coinsGained,
  questionsAnswered,
  hasNextLevel,
  onNextLevel,
  onMainMenu,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/65 backdrop-blur-sm animate-fade-in select-none">
      <div className="w-full max-w-md bg-pink-50 rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden text-center p-6 space-y-5 animate-scale-up">
        {/* Victory Stars & Header */}
        <div>
          <div className="flex justify-center items-center gap-2 mb-2">
            <span className="text-3xl animate-bounce">🍓</span>
            <span className="text-4xl text-amber-400 drop-shadow-md animate-bounce" style={{ animationDelay: '150ms' }}>
              ★
            </span>
            <span className="text-3xl animate-bounce" style={{ animationDelay: '300ms' }}>🍓</span>
          </div>
          <span className="text-xs font-bold text-rose-600 uppercase tracking-widest block">
            Luar Biasa, Sahabat Manis!
          </span>
          <h2 className="text-2xl md:text-3xl font-bold font-heading text-purple-950">
            {levelTitle} Selesai!
          </h2>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2 bg-white/90 p-3.5 rounded-2xl border border-pink-200 shadow-sm">
          <div className="flex flex-col items-center">
            <TrophyIcon className="w-5 h-5 text-purple-600 mb-1" />
            <span className="text-xs text-purple-800/70">Nilai</span>
            <span className="text-base font-bold text-purple-950 font-mono tabular-nums">
              +{scoreGained}
            </span>
          </div>

          <div className="flex flex-col items-center border-x border-pink-100">
            <CoinIcon className="w-5 h-5 mb-1" />
            <span className="text-xs text-purple-800/70">Koin Stroberi</span>
            <span className="text-base font-bold text-rose-700 font-mono tabular-nums">
              +{coinsGained}
            </span>
          </div>

          <div className="flex flex-col items-center">
            <CheckCircleIcon className="w-5 h-5 text-emerald-500 mb-1" />
            <span className="text-xs text-purple-800/70">Tantangan</span>
            <span className="text-base font-bold text-emerald-800 font-mono tabular-nums">
              {questionsAnswered} Soal
            </span>
          </div>
        </div>

        {/* Supportive educational quote */}
        <p className="text-xs text-purple-900 bg-purple-100/60 p-3 rounded-2xl border border-purple-200 leading-relaxed">
          Kamu semakin pintar mengenali makanan dan minuman manis yang sehat! Ayo lanjutkan petualangan manismu ke tantangan berikutnya.
        </p>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1">
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onNextLevel();
            }}
            className="w-full py-3.5 px-4 rounded-2xl font-bold font-heading text-base bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shadow-md active:scale-95 transition-all"
          >
            {hasNextLevel ? 'Lanjut ke Level Berikutnya →' : 'Lihat Hasil Akhir Petualangan! 🏆'}
          </button>

          <button
            onClick={() => {
              soundManager.playSFX('click');
              onMainMenu();
            }}
            className="w-full py-2.5 px-4 rounded-2xl font-semibold text-sm bg-white hover:bg-pink-50 text-purple-900 border border-purple-200 transition-all"
          >
            Kembali ke Menu Utama
          </button>
        </div>
      </div>
    </div>
  );
};

