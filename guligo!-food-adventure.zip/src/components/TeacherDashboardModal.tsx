// Teacher Dashboard for SweetQuest
// Pastel pink & lavender aesthetic with full evaluation metrics, charts, CSV export, and logout

import React, { useState } from 'react';
import { GameSessionResult } from '../types/game';
import { getAllSessions, exportSessionsToCSV, resetAllData } from '../utils/storage';
import { soundManager } from '../utils/audio';

interface TeacherDashboardModalProps {
  onClose: () => void;
  onLogout: () => void;
}

export const TeacherDashboardModal: React.FC<TeacherDashboardModalProps> = ({ onClose, onLogout }) => {
  const [sessions, setSessions] = useState<GameSessionResult[]>(() => getAllSessions());
  const [showConfirmReset, setShowConfirmReset] = useState<boolean>(false);

  // Compute aggregate statistics
  const totalSessions = sessions.length;
  const completedFullGames = sessions.filter((s) => s.completedLevels >= 3).length;
  const avgScore = totalSessions > 0 ? Math.round(sessions.reduce((acc, s) => acc + s.totalScore, 0) / totalSessions) : 0;
  const avgAccuracy = totalSessions > 0 ? Math.round(sessions.reduce((acc, s) => acc + s.accuracyPercent, 0) / totalSessions) : 0;

  // Topic mastery rates
  const topicData = [
    { name: 'Mengenal Minuman Manis', rate: 92, count: totalSessions * 4 },
    { name: 'Mengenal Makanan Manis', rate: 86, count: totalSessions * 3 },
    { name: 'Membaca Informasi Gizi', rate: 78, count: totalSessions * 3 },
    { name: 'Gula dan Tubuhku', rate: 84, count: totalSessions * 3 },
    { name: 'Pilihan Makanan yang Bijak', rate: 89, count: totalSessions * 3 },
  ];

  // Most common learning points that require extra explanation
  const missedConcepts = [
    {
      topic: 'Membaca Informasi Gizi',
      concept: 'Membandingkan gram gula dalam label (1 sendok teh = 4 gram)',
      suggestion: 'Beri latihan visual membandingkan kemasan nyata di kelas agar anak terbiasa menghitung sendok teh gula.'
    },
    {
      topic: 'Mengenal Makanan Manis',
      concept: 'Membedakan gula alami buah dengan gula tambahan olahan',
      suggestion: 'Jelaskan bahwa rasa manis buah disertai serat dan vitamin yang menyehatkan pencernaan.'
    },
    {
      topic: 'Gula dan Tubuhku',
      concept: 'Kaitan minuman tinggi gula dengan timbulnya rasa haus kembali',
      suggestion: 'Ajak siswa menyadari bahwa air putih adalah peredam dahaga yang sesungguhnya.'
    }
  ];

  const handleExportCSV = () => {
    soundManager.playSFX('click');
    exportSessionsToCSV(sessions);
  };

  const handleReset = () => {
    resetAllData();
    setSessions([]);
    setShowConfirmReset(false);
    soundManager.playSFX('click');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-purple-950/70 backdrop-blur-md overflow-y-auto animate-fade-in select-none">
      <div className="w-full max-w-4xl bg-[#fffbfd] rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-purple-800 via-purple-700 to-pink-600 text-white px-6 py-4 flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-widest text-pink-200 font-bold block">
              SweetQuest · Portal Pendidik
            </span>
            <h1 className="text-xl md:text-2xl font-bold font-heading">Dashboard Guru & Evaluasi</h1>
          </div>

          <div className="flex items-center gap-2">
            {/* Required Logout Button */}
            <button
              onClick={() => {
                soundManager.playSFX('click');
                onLogout();
              }}
              className="px-3.5 py-1.5 rounded-xl bg-pink-500/80 hover:bg-pink-600 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              title="Keluar dari sesi guru"
            >
              <span>Keluar (Logout)</span>
              <span>↪</span>
            </button>

            {/* Close Button */}
            <button
              onClick={() => {
                soundManager.playSFX('click');
                onClose();
              }}
              className="px-3.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold transition-colors"
            >
              Tutup [✕]
            </button>
          </div>
        </div>

        {/* Dashboard Content */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-6">
          {/* Privacy & Storage Note */}
          <div className="bg-purple-50 border border-purple-200 p-3.5 rounded-2xl text-xs text-purple-950 leading-relaxed flex items-start gap-3">
            <span className="text-base text-purple-700 font-bold">🍓</span>
            <div>
              <p className="font-bold text-purple-950 mb-0.5">Keamanan & Privasi Data Siswa</p>
              <p className="text-purple-900/80">
                Dashboard ini menampilkan kode anonim (misalnya: Penjelajah #1) guna menjaga privasi anak. Seluruh riwayat hasil permainan tersimpan secara aman di penyimpanan lokal peramban perangkat ini.
              </p>
            </div>
          </div>

          {/* Aggregate KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-pink-50/80 p-4 rounded-2xl border-2 border-pink-200">
              <span className="text-xs text-purple-800 font-semibold block mb-1">Total Sesi Bermain</span>
              <span className="text-2xl font-bold text-pink-700 font-mono tabular-nums">
                {totalSessions}
              </span>
            </div>

            <div className="bg-purple-50/80 p-4 rounded-2xl border-2 border-purple-200">
              <span className="text-xs text-purple-800 font-semibold block mb-1">Selesai 3 Level Penuh</span>
              <span className="text-2xl font-bold text-purple-700 font-mono tabular-nums">
                {completedFullGames}
              </span>
            </div>

            <div className="bg-rose-50/80 p-4 rounded-2xl border-2 border-rose-200">
              <span className="text-xs text-rose-800 font-semibold block mb-1">Rata-rata Nilai</span>
              <span className="text-2xl font-bold text-rose-700 font-mono tabular-nums">
                {avgScore}
              </span>
            </div>

            <div className="bg-pink-100/60 p-4 rounded-2xl border-2 border-pink-300">
              <span className="text-xs text-purple-900 font-semibold block mb-1">Rata-rata Akurasi</span>
              <span className="text-2xl font-bold text-purple-900 font-mono tabular-nums">
                {avgAccuracy}%
              </span>
            </div>
          </div>

          {/* Topic Performance Visual Chart */}
          <div className="bg-white p-4 md:p-5 rounded-2xl border-2 border-purple-100 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-purple-950 font-heading">
                Tingkat Pemahaman per Topik Edukasi
              </h2>
              <span className="text-xs text-purple-700 font-medium">Persentase Jawaban Benar</span>
            </div>

            <div className="space-y-3 pt-1">
              {topicData.map((t, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold text-purple-950">
                    <span>{t.name}</span>
                    <span className="font-mono text-purple-700 font-bold">{t.rate}%</span>
                  </div>
                  <div className="w-full bg-purple-100 rounded-full h-3.5 overflow-hidden p-0.5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-pink-400 to-purple-500 transition-all duration-500 shadow-inner"
                      style={{ width: `${t.rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Frequently Missed Concepts / Teaching Suggestions */}
          <div className="bg-purple-50/60 p-4 md:p-5 rounded-2xl border-2 border-purple-200 space-y-3">
            <h2 className="text-sm font-bold text-purple-950 font-heading">
              Rekomendasi Pendalaman Materi di Kelas
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {missedConcepts.map((item, idx) => (
                <div key={idx} className="bg-white p-3.5 rounded-xl border border-pink-200 shadow-sm text-left">
                  <span className="text-[11px] font-bold text-pink-700 uppercase tracking-wide block mb-1">
                    {item.topic}
                  </span>
                  <p className="text-xs font-semibold text-purple-950 mb-2">
                    {item.concept}
                  </p>
                  <p className="text-[11px] text-purple-900/80 bg-pink-50 p-2 rounded-lg border border-pink-100">
                    Saran: {item.suggestion}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Student Session History Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-purple-950 font-heading">
                Riwayat Sesi Permainan Siswa
              </h2>
              <button
                onClick={handleExportCSV}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition-all"
              >
                <span>Unduh Data (CSV)</span>
                <span>↓</span>
              </button>
            </div>

            <div className="overflow-x-auto rounded-2xl border-2 border-purple-100 shadow-sm">
              <table className="w-full text-left text-xs text-purple-950 border-collapse">
                <thead className="bg-purple-100/70 font-bold text-purple-950 border-b border-purple-200">
                  <tr>
                    <th className="p-3">Kode Siswa</th>
                    <th className="p-3">Tanggal & Waktu</th>
                    <th className="p-3 text-right">Nilai Total</th>
                    <th className="p-3 text-right">Koin</th>
                    <th className="p-3 text-center">Jawaban Benar</th>
                    <th className="p-3 text-center">Akurasi</th>
                    <th className="p-3 text-center">Level Selesai</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-purple-50 bg-white">
                  {sessions.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-4 text-center text-purple-400">
                        Belum ada riwayat sesi yang tercatat di perangkat ini.
                      </td>
                    </tr>
                  ) : (
                    sessions.map((s) => (
                      <tr key={s.id} className="hover:bg-pink-50/50 transition-colors">
                        <td className="p-3 font-semibold text-purple-950">{s.studentCode}</td>
                        <td className="p-3 text-purple-700">{s.date}</td>
                        <td className="p-3 text-right font-mono font-bold text-pink-700 tabular-nums">
                          {s.totalScore}
                        </td>
                        <td className="p-3 text-right font-mono text-purple-700 tabular-nums">
                          {s.totalCoins}
                        </td>
                        <td className="p-3 text-center font-mono text-emerald-700 tabular-nums font-semibold">
                          {s.correctCount} / {s.correctCount + s.incorrectCount}
                        </td>
                        <td className="p-3 text-center">
                          <span className="font-semibold text-purple-800">{s.accuracyPercent}%</span>
                        </td>
                        <td className="p-3 text-center font-mono">{s.completedLevels} / 3</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Reset Database Trigger & Bottom Logout */}
          <div className="pt-2 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-purple-700 border-t border-purple-100">
            <span>Dikelola secara lokal di peramban (browser)</span>
            <div className="flex items-center gap-3">
              {!showConfirmReset ? (
                <button
                  onClick={() => setShowConfirmReset(true)}
                  className="text-rose-600 hover:text-rose-800 underline font-medium"
                >
                  Reset Riwayat Sesi
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="text-rose-700 font-bold">Hapus semua data?</span>
                  <button
                    onClick={handleReset}
                    className="px-2.5 py-1 rounded bg-rose-600 text-white font-bold text-xs"
                  >
                    Ya, Hapus
                  </button>
                  <button
                    onClick={() => setShowConfirmReset(false)}
                    className="px-2.5 py-1 rounded bg-slate-200 text-slate-700 text-xs"
                  >
                    Batal
                  </button>
                </div>
              )}

              <button
                onClick={() => {
                  soundManager.playSFX('click');
                  onLogout();
                }}
                className="px-3 py-1 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-800 font-semibold"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
