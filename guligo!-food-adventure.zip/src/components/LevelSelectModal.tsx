// Level Select Modal for SweetQuest
// Choose and replay unlocked adventure stages in pastel strawberry/lavender style

import React from 'react';
import { LEVELS } from '../game/levels';
import { soundManager } from '../utils/audio';

interface LevelSelectModalProps {
  unlockedLevel: number;
  onSelectLevel: (levelId: number) => void;
  onClose: () => void;
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  unlockedLevel,
  onSelectLevel,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/60 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-xl bg-[#fffbfd] rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-500 via-pink-600 to-purple-600 text-white px-6 py-4 flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-widest text-pink-200 font-bold block">
              Pilih Wilayah Petualangan
            </span>
            <h2 className="text-xl md:text-2xl font-bold font-heading">Pilih Level</h2>
          </div>
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onClose();
            }}
            className="px-3 py-1 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold"
          >
            ✕
          </button>
        </div>

        {/* Level List */}
        <div className="p-5 md:p-6 space-y-3.5">
          {LEVELS.map((lvl) => {
            const isUnlocked = lvl.id <= unlockedLevel;

            return (
              <div
                key={lvl.id}
                onClick={() => {
                  if (isUnlocked) {
                    soundManager.playSFX('click');
                    onSelectLevel(lvl.id);
                  }
                }}
                className={`p-4 rounded-2xl border-2 transition-all flex items-center justify-between gap-4 ${
                  isUnlocked
                    ? 'bg-white hover:bg-pink-50/60 border-pink-200 cursor-pointer shadow-sm hover:shadow-md hover:-translate-y-0.5'
                    : 'bg-purple-50/40 border-purple-100 opacity-60 cursor-not-allowed'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg font-heading shrink-0 shadow-inner ${
                      isUnlocked
                        ? 'bg-gradient-to-tr from-rose-500 to-pink-500 text-white'
                        : 'bg-purple-200 text-purple-400'
                    }`}
                  >
                    {lvl.id}
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-purple-950 font-heading">
                      {lvl.title}
                    </h3>
                    <p className="text-xs text-purple-800/70">{lvl.subtitle}</p>
                    <span className="inline-block mt-1 text-[11px] font-semibold text-pink-700">
                      Fokus: {lvl.learningFocus}
                    </span>
                  </div>
                </div>

                <div className="shrink-0">
                  {isUnlocked ? (
                    <span className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-pink-500 text-white font-bold text-xs shadow-sm">
                      Mulai Main →
                    </span>
                  ) : (
                    <span className="text-xs font-semibold text-purple-400">Terkunci</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="bg-pink-50 px-6 py-3.5 border-t border-pink-200 flex justify-end">
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onClose();
            }}
            className="px-6 py-2 rounded-2xl font-bold font-heading text-sm bg-white hover:bg-purple-50 text-purple-800 border border-purple-200 transition-all"
          >
            Kembali
          </button>
        </div>
      </div>
    </div>
  );
};
