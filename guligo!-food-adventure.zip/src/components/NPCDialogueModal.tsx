// NPC Dialogue Modal for SweetQuest
// Strawberry Shortcake inspired character dialogues

import React, { useState } from 'react';
import { NPC } from '../types/game';
import { soundManager } from '../utils/audio';

interface NPCDialogueModalProps {
  npc: NPC;
  onClose: () => void;
}

export const NPCDialogueModal: React.FC<NPCDialogueModalProps> = ({ npc, onClose }) => {
  const [dialogueIndex, setDialogueIndex] = useState(0);

  const handleNext = () => {
    soundManager.playSFX('click');
    if (dialogueIndex < npc.dialogue.length - 1) {
      setDialogueIndex(dialogueIndex + 1);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 md:p-6 bg-purple-950/60 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-xl bg-[#fffbfd] rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden flex flex-col">
        {/* Character bar */}
        <div className="bg-gradient-to-r from-rose-500 via-pink-600 to-purple-600 px-5 py-3 text-white flex items-center justify-between">
          <div>
            <h3 className="text-base md:text-lg font-bold font-heading">{npc.name}</h3>
            <span className="text-xs text-pink-100">{npc.title}</span>
          </div>
          <span className="text-xs bg-white/20 px-2.5 py-1 rounded-full font-medium">
            Halaman {dialogueIndex + 1} dari {npc.dialogue.length}
          </span>
        </div>

        {/* Dialogue Body */}
        <div className="p-5 md:p-6 flex items-start gap-4">
          {/* Avatar frame */}
          <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-gradient-to-tr from-pink-100 to-purple-100 border-2 border-pink-300 flex items-center justify-center shrink-0 shadow-inner overflow-hidden">
            {npc.avatar === 'pak_arif' && (
              <div className="flex flex-col items-center">
                <span className="text-xl">👒</span>
                <span className="text-[10px] font-bold text-purple-900 font-heading">Pak Arif</span>
              </div>
            )}
            {npc.avatar === 'koki_ratna' && (
              <div className="flex flex-col items-center">
                <span className="text-xl">🧁</span>
                <span className="text-[10px] font-bold text-pink-900 font-heading">Koki Ratna</span>
              </div>
            )}
            {npc.avatar === 'dokter_gita' && (
              <div className="flex flex-col items-center">
                <span className="text-xl">🩺</span>
                <span className="text-[10px] font-bold text-purple-900 font-heading">Dokter Gita</span>
              </div>
            )}
          </div>

          {/* Speech text */}
          <div className="flex-1 bg-white p-4 rounded-2xl border-2 border-pink-100 shadow-sm min-h-[90px] flex items-center">
            <p className="text-sm md:text-base text-purple-950 leading-relaxed font-medium">
              "{npc.dialogue[dialogueIndex]}"
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-pink-50 px-5 py-3 border-t border-pink-200 flex items-center justify-end">
          <button
            onClick={handleNext}
            className="px-6 py-2.5 rounded-2xl font-bold font-heading text-sm md:text-base bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shadow-md active:scale-95 transition-all"
          >
            {dialogueIndex < npc.dialogue.length - 1 ? 'Lanjut →' : 'Mengerti, Mulai Jelajah!'}
          </button>
        </div>
      </div>
    </div>
  );
};
