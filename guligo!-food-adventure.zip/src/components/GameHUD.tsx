// In-game HUD and Touch Controls for SweetQuest
// Pastel strawberry pink & lavender purple aesthetic

import React from 'react';
import { HeartIcon, CoinIcon, TrophyIcon, PauseIcon, QuestionCircleIcon } from './GameIcons';

interface GameHUDProps {
  levelTitle: string;
  lives: number;
  maxLives: number;
  coins: number;
  score: number;
  completedQuestions: number;
  totalQuestions: number;
  onPause: () => void;
  onTouchAction: (action: 'left' | 'right' | 'jump' | 'interact', active: boolean) => void;
  toastMessage?: string | null;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  levelTitle,
  lives,
  maxLives,
  coins,
  score,
  completedQuestions,
  totalQuestions,
  onPause,
  onTouchAction,
  toastMessage,
}) => {
  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 md:p-5 select-none z-20">
      {/* Top Bar HUD */}
      <div className="flex items-center justify-between gap-3 w-full max-w-5xl mx-auto">
        {/* Left: Level Title & Hearts */}
        <div className="pointer-events-auto flex items-center gap-3 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-2xl shadow-sm border-2 border-pink-200">
          <div className="hidden sm:block">
            <span className="text-[10px] font-bold text-pink-600 uppercase tracking-wider block">Petualangan</span>
            <span className="text-sm font-bold text-purple-950 font-heading">{levelTitle}</span>
          </div>
          <div className="h-6 w-px bg-pink-200 hidden sm:block" />
          {/* Hearts (Nyawa) */}
          <div className="flex items-center gap-1" title={`Nyawa: ${lives} dari ${maxLives}`}>
            {Array.from({ length: maxLives }).map((_, i) => (
              <HeartIcon
                key={i}
                filled={i < lives}
                className="w-5 h-5 transition-transform duration-200"
              />
            ))}
          </div>
        </div>

        {/* Center: Toast notification */}
        {toastMessage && (
          <div className="pointer-events-auto animate-bounce bg-gradient-to-r from-rose-500 to-pink-500 text-white text-xs md:text-sm font-bold px-4 py-1.5 rounded-full shadow-lg border-2 border-white">
            {toastMessage}
          </div>
        )}

        {/* Right: Coins, Score, Quest Progress, Pause */}
        <div className="pointer-events-auto flex items-center gap-2 md:gap-3 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-2xl shadow-sm border-2 border-pink-200">
          {/* Coins */}
          <div className="flex items-center gap-1.5" title="Koin Terkumpul">
            <CoinIcon className="w-5 h-5" />
            <span className="text-sm font-bold text-amber-900 font-mono tabular-nums">{coins}</span>
          </div>

          <div className="h-4 w-px bg-pink-200" />

          {/* Score */}
          <div className="flex items-center gap-1.5" title="Nilai Petualang">
            <TrophyIcon className="w-5 h-5" />
            <span className="text-sm font-bold text-purple-950 font-mono tabular-nums">{score}</span>
          </div>

          <div className="h-4 w-px bg-pink-200 hidden md:block" />

          {/* Challenge progress */}
          <div className="hidden md:flex items-center gap-1.5" title="Kemajuan Tantangan Soal">
            <QuestionCircleIcon className="w-4 h-4" />
            <span className="text-xs font-bold text-purple-800">
              Tantangan: {completedQuestions}/{totalQuestions}
            </span>
          </div>

          <div className="h-4 w-px bg-pink-200" />

          {/* Pause Button */}
          <button
            onClick={onPause}
            className="p-1.5 rounded-xl hover:bg-pink-100 text-purple-900 transition-colors"
            title="Jeda Permainan"
            aria-label="Jeda Permainan"
          >
            <PauseIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Bottom: Mobile / Touch Controls Overlay */}
      <div className="w-full flex items-end justify-between pb-1 pointer-events-none">
        {/* Left / Right directional pad */}
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onPointerDown={() => onTouchAction('left', true)}
            onPointerUp={() => onTouchAction('left', false)}
            onPointerLeave={() => onTouchAction('left', false)}
            className="w-14 h-14 rounded-2xl bg-purple-900/80 active:bg-pink-500 text-white backdrop-blur-sm shadow-lg flex items-center justify-center font-bold text-2xl transition-transform active:scale-95 touch-none border-2 border-pink-200"
            aria-label="Gerak ke Kiri"
          >
            ←
          </button>
          <button
            onPointerDown={() => onTouchAction('right', true)}
            onPointerUp={() => onTouchAction('right', false)}
            onPointerLeave={() => onTouchAction('right', false)}
            className="w-14 h-14 rounded-2xl bg-purple-900/80 active:bg-pink-500 text-white backdrop-blur-sm shadow-lg flex items-center justify-center font-bold text-2xl transition-transform active:scale-95 touch-none border-2 border-pink-200"
            aria-label="Gerak ke Kanan"
          >
            →
          </button>
        </div>

        {/* Action pad (Jump & Interact) */}
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onPointerDown={() => onTouchAction('interact', true)}
            onPointerUp={() => onTouchAction('interact', false)}
            onPointerLeave={() => onTouchAction('interact', false)}
            className="w-14 h-14 rounded-2xl bg-purple-600/90 active:bg-purple-700 text-white font-bold backdrop-blur-sm shadow-lg flex flex-col items-center justify-center text-xs transition-transform active:scale-95 touch-none border-2 border-purple-300"
            aria-label="Interaksi"
          >
            <span className="font-heading font-bold text-sm">Bicara</span>
            <span className="text-[10px] text-purple-200">[E]</span>
          </button>
          <button
            onPointerDown={() => onTouchAction('jump', true)}
            onPointerUp={() => onTouchAction('jump', false)}
            onPointerLeave={() => onTouchAction('jump', false)}
            className="w-16 h-16 rounded-2xl bg-rose-500/90 active:bg-rose-600 text-white font-bold backdrop-blur-sm shadow-lg flex flex-col items-center justify-center transition-transform active:scale-95 touch-none border-2 border-rose-300"
            aria-label="Lompat"
          >
            <span className="text-xl">↑</span>
            <span className="text-[11px] font-heading font-bold">Lompat</span>
          </button>
        </div>
      </div>
    </div>
  );
};
