// Commercial-Grade Home Screen for SweetQuest
// Strawberry Shortcake inspired whimsical fantasy world, adorable cartoon mascot, and pastel pink/lavender controls

import React from 'react';
import { TrophyIcon, CoinIcon, StrawberryIcon } from './GameIcons';
import { soundManager } from '../utils/audio';

interface MainMenuProps {
  onStartGame: () => void;
  onOpenLevelSelect: () => void;
  onOpenHowToPlay: () => void;
  onOpenSettings: () => void;
  onOpenTeacherDashboard: () => void;
  onOpenCredits: () => void;
  unlockedLevel: number;
  highScore: number;
  totalCoins: number;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartGame,
  onOpenLevelSelect,
  onOpenHowToPlay,
  onOpenSettings,
  onOpenTeacherDashboard,
  onOpenCredits,
  unlockedLevel,
  highScore,
  totalCoins,
}) => {
  return (
    <div className="relative w-full h-screen overflow-hidden flex flex-col justify-between select-none bg-gradient-to-b from-[#fce7f3] via-[#fdf2f8] to-[#f3e8ff]">
      {/* Whimsical Illustrated Strawberry Fantasy World Background */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Soft pastel sun rays & floating cotton-candy clouds */}
        <div className="absolute top-8 left-10 w-52 h-16 bg-white/80 rounded-full blur-[1px] animate-pulse" />
        <div className="absolute top-20 right-16 w-64 h-20 bg-white/70 rounded-full blur-[1px]" />
        <div className="absolute top-36 left-1/4 w-44 h-14 bg-pink-100/60 rounded-full blur-[1px]" />

        {/* Distant soft lavender peaks */}
        <svg
          className="absolute bottom-28 w-full h-64 text-purple-200/70"
          preserveAspectRatio="none"
          viewBox="0 0 1200 320"
          fill="currentColor"
        >
          <path d="M0 320 L0 180 Q300 70 600 190 T1200 150 L1200 320 Z" />
        </svg>

        {/* Midground rolling pastel pink strawberry knolls */}
        <svg
          className="absolute bottom-16 w-full h-56 text-pink-200/80"
          preserveAspectRatio="none"
          viewBox="0 0 1200 280"
          fill="currentColor"
        >
          <path d="M0 280 L0 140 Q400 50 800 160 T1200 110 L1200 280 Z" />
        </svg>

        {/* Foreground fresh mint-green strawberry garden hill */}
        <svg
          className="absolute bottom-0 w-full h-36 text-emerald-400"
          preserveAspectRatio="none"
          viewBox="0 0 1200 160"
          fill="currentColor"
        >
          <path d="M0 160 L0 60 Q300 15 600 65 T1200 45 L1200 160 Z" />
        </svg>

        {/* Ground crust border */}
        <div className="absolute bottom-0 inset-x-0 h-9 bg-pink-400 border-t-4 border-emerald-300" />
      </div>

      {/* Top Header Bar: High Score, Coins, and Sound Settings */}
      <div className="relative z-10 w-full p-4 md:p-6 flex items-center justify-between max-w-5xl mx-auto">
        <div className="flex items-center gap-3 bg-white/90 backdrop-blur-md px-4 py-2 rounded-2xl shadow-sm border-2 border-pink-200">
          <div className="flex items-center gap-2">
            <TrophyIcon className="w-5 h-5 text-purple-500" />
            <span className="text-xs text-purple-900 font-semibold">Skor Terbaik:</span>
            <span className="text-sm font-bold text-pink-700 font-mono tabular-nums">
              {highScore}
            </span>
          </div>
          <div className="h-4 w-px bg-pink-200" />
          <div className="flex items-center gap-1.5">
            <CoinIcon className="w-4 h-4" />
            <span className="text-sm font-bold text-amber-900 font-mono tabular-nums">
              {totalCoins}
            </span>
          </div>
        </div>

        {/* Settings button */}
        <button
          onClick={() => {
            soundManager.playSFX('click');
            onOpenSettings();
          }}
          className="p-2.5 rounded-2xl bg-white/90 hover:bg-white text-purple-800 hover:text-pink-600 shadow-sm border-2 border-pink-200 transition-all active:scale-95"
          title="Pengaturan Suara"
          aria-label="Pengaturan Suara"
        >
          <span className="text-base font-bold">⚙</span>
        </button>
      </div>

      {/* Center Layout: Mascot Illustration + Title SweetQuest + Main Controls */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-4 max-w-lg mx-auto space-y-4 my-auto">
        {/* Adorable Strawberry Character Avatar / Mascot Centerpiece */}
        <div className="relative animate-sweet-float">
          {/* Glowing pastel aura ring */}
          <div className="w-32 h-32 md:w-36 md:h-36 rounded-full bg-gradient-to-tr from-pink-300 via-pink-100 to-purple-200 p-1.5 shadow-xl border-4 border-white flex items-center justify-center">
            {/* Detailed Vector Cartoon Mascot Face */}
            <div className="w-full h-full rounded-full bg-gradient-to-b from-[#fff5f7] to-[#fed7aa] flex flex-col items-center justify-center relative overflow-hidden">
              {/* Cute Strawberry Beret */}
              <div className="w-20 h-10 bg-rose-500 rounded-t-full relative -mt-3 shadow-sm border border-rose-600">
                {/* Yellow seeds */}
                <div className="absolute top-2 left-4 w-1 h-1 bg-yellow-200 rounded-full" />
                <div className="absolute top-2 right-4 w-1 h-1 bg-yellow-200 rounded-full" />
                <div className="absolute top-4 left-9 w-1 h-1 bg-yellow-200 rounded-full" />
                {/* Calyx leaf */}
                <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-6 h-2 bg-emerald-400 rounded-full" />
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-1.5 h-3 bg-emerald-600 rounded-sm" />
              </div>

              {/* Pastel Pink Hair Curls */}
              <div className="flex gap-4 -mt-1.5">
                <div className="w-4 h-4 bg-pink-400 rounded-full -ml-3" />
                <div className="w-4 h-4 bg-pink-400 rounded-full -mr-3" />
              </div>

              {/* Face: Anime Eyes & Smile */}
              <div className="flex gap-4 mt-0.5">
                <div className="w-2.5 h-3 bg-purple-900 rounded-full relative">
                  <div className="w-1 h-1 bg-white rounded-full absolute top-0.5 right-0.5" />
                </div>
                <div className="w-2.5 h-3 bg-purple-900 rounded-full relative">
                  <div className="w-1 h-1 bg-white rounded-full absolute top-0.5 right-0.5" />
                </div>
              </div>

              {/* Blushing cheeks */}
              <div className="flex gap-6 -mt-1">
                <div className="w-3 h-1.5 bg-rose-300/80 rounded-full" />
                <div className="w-3 h-1.5 bg-rose-300/80 rounded-full" />
              </div>

              {/* Sweet smile */}
              <div className="w-3 h-1.5 border-b-2 border-rose-600 rounded-full mt-0.5" />
            </div>
          </div>

          {/* Strawberry badge tag */}
          <div className="absolute -bottom-1 -right-1 bg-rose-500 text-white p-1 rounded-full shadow-md border-2 border-white">
            <StrawberryIcon className="w-5 h-5 text-white" />
          </div>
        </div>

        {/* Primary Game Identity: SweetQuest (NO tagline or slogan underneath!) */}
        <div className="pt-1">
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold font-heading text-transparent bg-clip-text bg-gradient-to-r from-rose-500 via-pink-600 to-purple-600 drop-shadow-sm tracking-tight leading-none">
            SweetQuest
          </h1>
        </div>

        {/* Navigation Action Buttons (Styled in Strawberry Pink & Lavender Purple) */}
        <div className="w-full max-w-xs space-y-2.5 pt-2">
          {/* Most prominent "Mulai Bermain" button */}
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onStartGame();
            }}
            className="w-full py-4 px-6 rounded-2xl font-bold font-heading text-xl md:text-2xl bg-gradient-to-r from-rose-500 via-pink-500 to-rose-600 hover:from-rose-600 hover:to-pink-600 text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all border-2 border-rose-300 animate-sweet-pulse"
          >
            Mulai Bermain ▶
          </button>

          {/* Petunjuk Bermain button */}
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onOpenHowToPlay();
            }}
            className="w-full py-2.5 px-4 rounded-2xl font-bold font-heading text-sm bg-white hover:bg-pink-50 text-purple-900 border-2 border-pink-200 shadow-sm transition-all"
          >
            Petunjuk Bermain
          </button>

          {/* Bottom Dual Buttons: Dashboard Guru & Tentang Game */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                soundManager.playSFX('click');
                onOpenTeacherDashboard();
              }}
              className="py-2.5 px-3 rounded-2xl font-bold font-heading text-xs bg-purple-100 hover:bg-purple-200 text-purple-950 border-2 border-purple-300 transition-all text-center flex items-center justify-center gap-1 shadow-sm"
            >
              <span>🔒</span>
              <span>Dashboard Guru</span>
            </button>
            <button
              onClick={() => {
                soundManager.playSFX('click');
                onOpenCredits();
              }}
              className="py-2.5 px-3 rounded-2xl font-bold font-heading text-xs bg-pink-100 hover:bg-pink-200 text-pink-950 border-2 border-pink-300 transition-all text-center flex items-center justify-center gap-1 shadow-sm"
            >
              <span>🍓</span>
              <span>Tentang Game</span>
            </button>
          </div>
        </div>
      </div>

      {/* Discreet footer notice */}
      <div className="relative z-10 w-full p-3 text-center text-[11px] text-purple-900/60 font-medium">
        <span>SweetQuest · Petualangan Edukasi Makanan Sehat</span>
      </div>
    </div>
  );
};
