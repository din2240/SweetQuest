// Credits & Game Info Modal for SweetQuest
// Pure original identity with no external company/studio branding

import React from 'react';
import { soundManager } from '../utils/audio';

interface CreditsModalProps {
  onClose: () => void;
}

export const CreditsModal: React.FC<CreditsModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/60 backdrop-blur-md animate-fade-in select-none">
      <div className="w-full max-w-md bg-[#fffbfd] rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden text-center">
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-500 via-pink-600 to-purple-600 text-white px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold font-heading">Tentang Game</h2>
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onClose();
            }}
            className="px-3 py-1 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-left text-xs text-purple-950 leading-relaxed">
          <div className="text-center pb-2 border-b border-pink-200">
            <h1 className="text-3xl font-bold font-heading text-transparent bg-clip-text bg-gradient-to-r from-rose-500 to-purple-600">
              SweetQuest
            </h1>
          </div>

          <div className="space-y-2">
            <p className="font-semibold text-purple-950">Tujuan Pembelajaran:</p>
            <ul className="list-disc pl-4 space-y-1 text-purple-900/80">
              <li>Mengenali makanan dan minuman yang mengandung gula tambahan.</li>
              <li>Memahami peran air putih sebagai pilihan utama untuk hidrasi tubuh.</li>
              <li>Membaca dan membandingkan gram gula pada informasi nilai gizi.</li>
              <li>Menjaga kesehatan gigi dan tubuh dari konsumsi gula berlebih.</li>
              <li>Menumbuhkan kemandirian anak dalam membuat pilihan makanan yang bijak.</li>
            </ul>
          </div>

          <div className="bg-pink-50/80 p-3 rounded-2xl border border-pink-200 text-purple-900/90">
            <p className="font-bold text-purple-950 mb-1">Sasaran Pengguna:</p>
            <p>Siswa Sekolah Dasar kelas 4–6 (usia sekitar 9–12 tahun).</p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-pink-50 px-6 py-3.5 border-t border-pink-200 flex justify-end">
          <button
            onClick={() => {
              soundManager.playSFX('click');
              onClose();
            }}
            className="px-6 py-2 rounded-2xl font-bold font-heading text-sm bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shadow-md active:scale-95 transition-all"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
