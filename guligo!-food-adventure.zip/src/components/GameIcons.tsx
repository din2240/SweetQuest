// Original custom SVG game icons for SweetQuest
// Strawberry Shortcake inspired pastel styling with cute berry details

import React from 'react';

export const StrawberryIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    className={className}
    aria-hidden="true"
  >
    {/* Strawberry berry body */}
    <path
      d="M12 21c-4.2 0-7.5-2.5-7.5-8.5 0-4.2 2.8-7.5 7.5-7.5s7.5 3.3 7.5 7.5c0 6-3.3 8.5-7.5 8.5z"
      fill="#f43f5e"
      stroke="#e11d48"
      strokeWidth="1.5"
    />
    {/* Strawberry seed dots */}
    <circle cx="9" cy="11" r="0.9" fill="#fef08a" />
    <circle cx="15" cy="11" r="0.9" fill="#fef08a" />
    <circle cx="12" cy="14" r="0.9" fill="#fef08a" />
    <circle cx="10" cy="17" r="0.8" fill="#fef08a" />
    <circle cx="14" cy="17" r="0.8" fill="#fef08a" />
    {/* Green leaf cap */}
    <path
      d="M12 5.5c-1-1.8-3.5-2-4.5-.5.8 1.5 2.2 2 4.5 2 2.3 0 3.7-.5 4.5-2-1-1.5-3.5-1.3-4.5.5z"
      fill="#4ade80"
      stroke="#22c55e"
      strokeWidth="1.2"
    />
    {/* Stem */}
    <path d="M12 4.5V2" stroke="#16a34a" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export const HeartIcon: React.FC<{ className?: string; filled?: boolean }> = ({
  className = 'w-6 h-6',
  filled = true,
}) => (
  <svg
    viewBox="0 0 24 24"
    fill={filled ? '#f43f5e' : 'none'}
    stroke={filled ? '#be123c' : '#d8b4fe'}
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
  </svg>
);

export const CoinIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="#facc15"
    stroke="#ca8a04"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <circle cx="12" cy="12" r="9" />
    <circle cx="12" cy="12" r="6" fill="#fde047" stroke="#ca8a04" strokeWidth="1.5" />
    <path d="M12 8v8M10 10h3.5a1.5 1.5 0 0 1 0 3H10" stroke="#854d0e" strokeWidth="1.5" />
  </svg>
);

export const TrophyIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="#c084fc"
    stroke="#7e22ce"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
    <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
    <path d="M4 22h16" />
    <path d="M10 14.66V17c0 .55-.45 1-1 1H8c-.55 0-1 .45-1 1v1h10v-1c0-.55-.45-1-1-1h-1c-.55 0-1-.45-1-1v-2.34" />
    <path d="M6 4h12a2 2 0 0 1 2 2v3a6 6 0 0 1-6 6h-4a6 6 0 0 1-6-6V6a2 2 0 0 1 2-2Z" />
  </svg>
);

export const FlagIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="#f472b6"
    stroke="#be185d"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" />
    <line x1="4" x2="4" y1="22" y2="15" />
  </svg>
);

export const WaterBottleIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="#38bdf8"
    stroke="#0284c7"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M9 2h6v3H9z" fill="#0284c7" />
    <path d="M8 5h8v2l-1 2v11a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2V9L8 7z" />
    <path d="M10 13h4M10 16h4" stroke="#ffffff" strokeWidth="1.5" />
  </svg>
);

export const AppleFruitIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="#f43f5e"
    stroke="#be123c"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M12 3c0 2-1 3-3 3" stroke="#15803d" strokeWidth="2" />
    <path d="M12 4c2-2 4-2 6 0 0 2-1 3-3 3" fill="#4ade80" stroke="#16a34a" />
    <path d="M12 21c-4 0-7-2-7-8 0-4 2-7 6-7 1 0 1.5.5 2 .5s1-.5 2-.5c4 0 6 3 6 7 0 6-3 8-7 8z" />
  </svg>
);

export const NutritionLabelIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="#fdf4ff"
    stroke="#7e22ce"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <rect x="4" y="3" width="16" height="18" rx="3" />
    <path d="M7 7h10M7 11h10M7 15h6M7 18h4" strokeWidth="1.5" />
  </svg>
);

export const CheckCircleIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="#f43f5e"
    stroke="#be123c"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <circle cx="12" cy="12" r="10" />
    <path d="m9 12 2 2 4-4" stroke="#ffffff" strokeWidth="2.5" />
  </svg>
);

export const QuestionCircleIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="#c084fc"
    stroke="#7e22ce"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <circle cx="12" cy="12" r="10" />
    <path
      d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01"
      stroke="#ffffff"
      strokeWidth="2.5"
    />
  </svg>
);

export const VolumeOnIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="currentColor" />
    <path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
    <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
  </svg>
);

export const VolumeMuteIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="currentColor" />
    <line x1="23" y1="9" x2="17" y2="15" />
    <line x1="17" y1="9" x2="23" y2="15" />
  </svg>
);

export const PauseIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    aria-hidden="true"
  >
    <rect x="6" y="4" width="4" height="16" rx="1.5" />
    <rect x="14" y="4" width="4" height="16" rx="1.5" />
  </svg>
);
