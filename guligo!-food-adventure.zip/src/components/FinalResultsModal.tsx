import React from 'react';
import { TrophyIcon, CoinIcon, CheckCircleIcon, AppleFruitIcon, WaterBottleIcon } from './GameIcons';
import { soundManager } from '../utils/audio';

interface FinalResultsModalProps {
  totalScore: number;
  totalCoins: number;
  correctCount: number;
  incorrectCount: number;
  completedLevels: number;
  onPlayAgain: () => void;
  onOpenTeacherDashboard: () => void;
  onMainMenu: () => void;
}

export const FinalResultsModal: React.FC<FinalResultsModalProps> = ({
  totalScore,
  totalCoins,
  correctCount,
  incorrectCount,
  completedLevels,
  onPlayAgain,
  onOpenTeacherDashboard,
  onMainMenu,
}) => {
  const totalQuestions = correctCount + incorrectCount;
  const accuracyPercent = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-purple-950/75 backdrop-blur-md overflow-y-auto animate-fade-in select-none">
      <div className="w-full max-w-2xl bg-pink-50 rounded-3xl shadow-2xl border-4 border-pink-300 overflow-hidden my-auto">
        {/* Certificate / Trophy Header */}
        <div className="bg-gradient-to-r from-rose-500 via-pink-500 to-purple-600 px-6 py-6 text-white text-center">
          <div className="inline-flex p-3 rounded-2xl bg-white/20 backdrop-blur-sm mb-2 shadow-inner">
            <TrophyIcon className="w-10 h-10 text-yellow-200" />
          </div>
          <span className="text-xs font-bold uppercase tracking-widest text-pink-100 block">
            Hasil Akhir Petualangan
          </span>
          <h1 className="text-2xl md:text-3xl font-bold font-heading text-white">
            Juara Petualang SweetQuest!
          </h1>
          <p className="text-xs md:text-sm text-pink-100 max-w-md mx-auto mt-1">
            SweetQuest — Petualangan Manis & Cerdas
          </p>
        </div>

        {/* Content Body */}
        <div className="p-5 md:p-7 space-y-5">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            {/* Total Nilai */}
            <div className="bg-white/90 p-3.5 rounded-2xl border border-pink-200 shadow-sm">
              <span className="text-xs text-purple-900/70 block mb-1">Total Nilai</span>
              <span className="text-xl md:text-2xl font-bold text-rose-600 font-mono tabular-nums">
                {totalScore}
              </span>
            </div>

            {/* Total Koin */}
            <div className="bg-white/90 p-3.5 rounded-2xl border border-pink-200 shadow-sm">
              <span className="text-xs text-purple-900/70 block mb-1">Koin Stroberi</span>
              <span className="text-xl md:text-2xl font-bold text-amber-600 font-mono tabular-nums">
                {totalCoins}
              </span>
            </div>

            {/* Jawaban Benar */}
            <div className="bg-white/90 p-3.5 rounded-2xl border border-pink-200 shadow-sm">
              <span className="text-xs text-purple-900/70 block mb-1">Jawaban Benar</span>
              <span className="text-xl md:text-2xl font-bold text-purple-700 font-mono tabular-nums">
                {correctCount} / {totalQuestions}
              </span>
            </div>

            {/* Akurasi Belajar */}
            <div className="bg-white/90 p-3.5 rounded-2xl border border-pink-200 shadow-sm">
              <span className="text-xs text-purple-900/70 block mb-1">Akurasi Soal</span>
              <span className="text-xl md:text-2xl font-bold text-emerald-600 font-mono tabular-nums">
                {accuracyPercent}%
              </span>
            </div>
          </div>

          {/* Topics Completed Checklist */}
          <div className="bg-white/90 p-4 rounded-2xl border border-pink-200 shadow-sm">
            <h3 className="text-xs font-bold text-purple-900/80 uppercase tracking-wider mb-2.5">
              Topik Pembelajaran yang Telah Dijelajahi
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-medium text-purple-950">
              <div className="flex items-center gap-2 p-2.5 bg-pink-50 rounded-xl border border-pink-100">
                <WaterBottleIcon className="w-4 h-4 text-rose-500" />
                <span>Mengenal Minuman Manis & Air Putih</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-pink-50 rounded-xl border border-pink-100">
                <AppleFruitIcon className="w-4 h-4 text-rose-500" />
                <span>Mengenal Makanan Manis & Camilan Buah</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-purple-50 rounded-xl border border-purple-100">
                <CheckCircleIcon className="w-4 h-4 text-purple-600" />
                <span>Membaca Informasi Gizi & Gram Gula</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 bg-purple-50 rounded-xl border border-purple-100">
                <CheckCircleIcon className="w-4 h-4 text-purple-600" />
                <span>Gula, Tubuhku, & Kesehatan Gigi</span>
              </div>
            </div>
          </div>

          {/* Encouraging Nonjudgmental Learning Summary */}
          <div className="bg-purple-100/60 p-4 rounded-2xl border border-purple-200 text-purple-950 text-xs md:text-sm leading-relaxed space-y-1.5">
            <h4 className="font-bold text-purple-950 font-heading text-sm md:text-base">
              Ringkasan Capaian Belajarmu
            </h4>
            <p>
              Hebat sekali! Dalam petualangan SweetQuest ini, kamu telah berhasil menjelajahi 3 level dan menguji pemahamanmu tentang minuman manis, makanan manis, serta cara membaca label gizi dengan tepat.
            </p>
            <p className="text-purple-900/80 text-xs">
              Catatan: Hasil ini mencerminkan pencapaianmu di dalam game. Yang terpenting adalah pengetahuan yang kamu dapatkan untuk selalu memperhatikan isi minuman dan makanan dalam kehidupan sehari-hari dengan bijak.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              onClick={() => {
                soundManager.playSFX('click');
                onPlayAgain();
              }}
              className="w-full sm:flex-1 py-3 px-4 rounded-2xl font-bold font-heading text-base bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white shadow-md active:scale-95 transition-all"
            >
              Mainkan Lagi ↺
            </button>

            <button
              onClick={() => {
                soundManager.playSFX('click');
                onOpenTeacherDashboard();
              }}
              className="w-full sm:flex-1 py-3 px-4 rounded-2xl font-bold font-heading text-sm bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-md active:scale-95 transition-all"
            >
              Dashboard Guru / Analisis
            </button>

            <button
              onClick={() => {
                soundManager.playSFX('click');
                onMainMenu();
              }}
              className="w-full sm:w-auto py-3 px-5 rounded-2xl font-semibold text-sm bg-white hover:bg-pink-50 text-purple-900 border border-purple-200 transition-all"
            >
              Menu Utama
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

